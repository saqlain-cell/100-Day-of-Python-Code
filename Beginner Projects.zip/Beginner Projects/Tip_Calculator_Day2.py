# print("Hello"[0]) # This is used to print the first character, a convenient way in python

# print("Hello"[len("Hello")-1]) # Used to get the last character

# print("Hello"[-1]) # also another way to get the last character

# print("Hello"[-2]) # used to get the second last character

# print(123_456_789 + 456_334) # As large numbers have commas in them like 236,000 to provide readability in english.
# That is how underscores are used for numbers here whether float or integers or
# any other, they are used for readability. it has no effect on the value itself

# # The following is used to give the type of the datatpye used
# print(type("Hello"))
# print(type(56))
# print(type(56.75))
# print(type(True))

# print("Number of letters in your name: " + len(input("Enter your name: "))) # identify the mistake in this line
# # The corrected line is the subsequent one, what we needed to do was concatenate string with string
# print("Number of letters in your name: " + str(len(input("Enter your name"))))

# Project

# print("Welcome to the tip calculator!")
#
# total_bill_without_tip = float(input("What was the total bill? $"))
#
# tip_percent = int(input("What percentage tip would you like to give? 10, 12, or 15? "))
#
# tip_percent_value = (total_bill_without_tip * tip_percent) / 100
#
# total_bill_with_tip = total_bill_without_tip + tip_percent_value
#
# no_of_eaters = int(input("How many people to split the bill? "))
#
# each_person_bill = round(total_bill_with_tip / no_of_eaters, 2)
#
# print(f"Each person should pay: ${each_person_bill}")
#
