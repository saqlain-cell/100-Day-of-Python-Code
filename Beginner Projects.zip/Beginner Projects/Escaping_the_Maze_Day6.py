import random


def function_name():
    print("Greeting")
