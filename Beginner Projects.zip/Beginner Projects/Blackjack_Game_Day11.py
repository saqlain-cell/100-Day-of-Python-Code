import random

# cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]


# want_to_play = None

# choice = input("Do you want to play BlackJack? Type 'y' or 'n': ")

# if choice == "y":
#     want_to_play = True
# else:
#     want_to_play = False

# while want_to_play:

#     user_cards = [random.choice(cards), random.choice(cards)]

#     computer_cards = [random.choice(cards), random.choice(cards)]

#     user_cards_text = ""
#     user_cards_score = 0

#     computer_cards_text = ""
#     computer_cards_score = 0

#     for card in computer_cards:
#         computer_cards_score += card
#         computer_cards_text += str(card) + ","

#     for card in user_cards:
#         user_cards_score += card
#         user_cards_text += str(card) + ","

#     print(
#         f"Your cards: [{user_cards_text.strip(",")}], current score: {user_cards_score}\n"
#     )

#     print(f"Computer's first card: {computer_cards[0]}\n")

#     # --------------------------------------------------------------------------------
#     while user_cards_score <= 21:

#         another_card_choice = input("Type 'y' to get another card, type 'n' to pass: ")

#         if another_card_choice != "y":
#             break

#         user_cards.append(random.choice(cards))
#         user_cards_score += user_cards[-1]
#         user_cards_text += str(user_cards[-1]) + ","

#         while user_cards_score > 21 and 11 in user_cards:
#             user_cards[user_cards.index(11)] = 1
#             user_cards_score -= 10
#             user_cards_text = ""
#             for card in user_cards:
#                 user_cards_text += str(card) + ","

#         print(
#             f"Your cards: [{user_cards_text.strip(",")}], current score: {user_cards_score}\n"
#         )

#         print(f"Computer's first card: {computer_cards[0]}\n")

#     # --------------------------------------------------------------------------------
#     if user_cards_score <= 21:
#         while computer_cards_score <= 16:
#             computer_cards.append(random.choice(cards))
#             computer_cards_score += computer_cards[-1]
#             while computer_cards_score > 21 and 11 in computer_cards:
#                 computer_cards[computer_cards.index(11)] = 1
#                 computer_cards_score -= 10
#                 computer_cards_text = ""
#                 for card in computer_cards:
#                     computer_cards_text += str(card) + ","
#             computer_cards_text += str(computer_cards[-1]) + ","

#     print(
#         f"Your final hand: [{user_cards_text.strip(",")}], final score: {user_cards_score}\n"
#     )

#     if user_cards_score > 21:
#         print(
#             f"Computer's final hand: [{computer_cards[0]}], final_score {computer_cards[0]}\n"
#         )
#     else:
#         print(
#             f"Computer's final hand: [{computer_cards_text.strip(",")}], final_score {computer_cards_score}\n"
#         )

#     if user_cards_score == computer_cards_score:
#         print("Draw")
#     elif user_cards_score > 21:
#         print("YOu went over, you lose big time")
#     elif computer_cards_score > 21:
#         print("The computer went over, you win")
#     elif user_cards_score == 21 and len(user_cards) == 2:
#         print("You have blackjack, you win")
#     elif computer_cards_score == 21 and len(computer_cards) == 2:
#         print("Computer has BlackJack, You lose")
#     elif user_cards_score > computer_cards_score:
#         print("You win, your score is greater")
#     elif user_cards_score < computer_cards_score:
#         print("You Lose, your score is less")

#     choice = input("Do you want to play BlackJack? Type 'y' or 'n': ")

#     if choice == "y":
#         want_to_play = True
#     else:
#         print("Goodbye")
#         want_to_play = False


# # Instructor Based Code, more cleaner

# def deal_card():
#     """Returns a random card from the deck"""
#     cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]
#     card = random.choice(cards)
#     return card


# def calculate_score(cards):
#     """Take a list of cards and return the score calculated from the cards"""
#     if sum(cards) == 21 and len(cards) == 2:
#         return 0

#     if 11 in cards and sum(cards) > 21:
#         cards.remove(11)
#         cards.append(1)

#     return sum(cards)


# def compare(u_score, c_score):
#     """Compares the user score u_score against the computer score c_score."""
#     if u_score == c_score:
#         return "Draw 🙃🙃"
#     elif c_score == 0:
#         return "Lose, opponent has Blackjack 😱"
#     elif u_score == 0:
#         return "Win with a Blackjack 😎"
#     elif u_score > 21:
#         return "You went over. You lose 😭"
#     elif c_score > 21:
#         return "Opponent went over. You win 😁"
#     elif u_score > c_score:
#         return "You win 😃"
#     else:
#         return "You lose 😤"


# def play_game():
#     print(logo)
#     user_cards = []
#     computer_cards = []
#     computer_score = -1
#     user_score = -1
#     is_game_over = False

#     for _ in range(2):
#         user_cards.append(deal_card())
#         computer_cards.append(deal_card())

#     while not is_game_over:
#         user_score = calculate_score(user_cards)
#         computer_score = calculate_score(computer_cards)
#         print(f"Your cards: {user_cards}, current score: {user_score}")
#         print(f"Computer's first card: {computer_cards[0]}")

#         if user_score == 0 or computer_score == 0 or user_score > 21:
#             is_game_over = True
#         else:
#             user_should_deal = input("Type 'y' to get another card, type 'n' to pass: ")
#             if user_should_deal == "y":
#                 user_cards.append(deal_card())
#             else:
#                 is_game_over = True

#     while computer_score != 0 and computer_score < 17:
#         computer_cards.append(deal_card())
#         computer_score = calculate_score(computer_cards)

#     print(f"Your final hand: {user_cards}, final score: {user_score}")
#     print(f"Computer's final hand: {computer_cards}, final score: {computer_score}")
#     print(compare(user_score, computer_score))


# while input("Do you want to play a game of Blackjack? Type 'y' or 'n': ") == "y":
#     print("\n" * 20)
#     play_game()

# # End
