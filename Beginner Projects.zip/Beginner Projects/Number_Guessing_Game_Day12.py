import random

# # Task

# enemies = 2

# def increase_enemies():
#     enemies = 5  # This does not modify the global enemies variable,
#     # because these are two different variables becuase of local scope and global scope

# # How to modify the global variable inside a function is discussed in the next task
# print(enemies)

# # End

# # Task
# enemies = 2

# def increase_enemies():
#     global enemies
#     enemies = 5  # now this is used to modify the global variable

# increase_enemies() # but first we have to call the function
# print(enemies)

# # End


# # Project, Number guessing Game

# EASY_LEVEL_ATTEMPTS = 10
# HARD_LEVEL_ATTEMPTS = 5


# def choose_difficulty():
#     difficulty = input("Choose a difficulty. Type 'easy' or 'hard': ")

#     if difficulty == "easy":
#         return EASY_LEVEL_ATTEMPTS
#     else:
#         return HARD_LEVEL_ATTEMPTS


# def check_guess(guessed_answer, random_number_answer, attempts):
#     if guessed_answer == random_number_answer:
#         print("You got it!!!")
#     elif guessed_answer < random_number_answer:
#         print("Too Low")
#         attempts -= 1
#     elif guessed_answer > random_number_answer:
#         print("Too High")
#         attempts -= 1

#     return attempts


# def game():
#     random_number_answer = random.randint(1, 100)

#     print("Welcome to the Number Guessing Game!")
#     print("I'm thinking of a number between 1 and 100.")
#     print(f"Pssst, the correct answer is {random_number_answer}")

#     attempts = choose_difficulty()

#     guessed_number = 0

#     while guessed_number != random_number_answer and attempts > 0:
#         print(f"You have {attempts} attempts remaining to guess the number")
#         guessed_number = int(input("Make a guess: "))

#         attempts = check_guess(guessed_number, random_number_answer, attempts)

#         if attempts == 0:
#             print("You have run out of guesses")
#         elif guessed_number != random_number_answer:
#             print("Guess again")


# game()

# # End
