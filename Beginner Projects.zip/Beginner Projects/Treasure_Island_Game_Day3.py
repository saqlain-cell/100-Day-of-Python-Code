# Task
# height = 12
# age = 20
#
# if height > 120:
#     print("You can ride the rollercoaster")
# elif age> 18:
#     print("You can ride the rollercoaster at your own risk")
# else:
#     print("You cannot ride the rollercoaster")
#
# End

# Task
# number_to_check = int(input("What is the number you want to check: "))
#
# if(number_to_check % 2 == 0):
#     print("Even")
# else:
#     print("Odd")

# End

# Task
# Nested if, else, elif conditions

# height = 120
#
# if(height > 120):
#     print("You can ride the rollercoaster")
#     age = int(input("How old are you? "))
#     if(age <= 18):
#             if(age <12):
#                 print("Please Pay 5$")
#             else:
#                 print("Please Pay 7$")
#     else:
#         print("Please Pay 12$")
# else:
#     print("Sorry you have to grow taller to ride the rollercoaster")
# End

# # Task
# height = 122
# ticket_price = None
#
# if height > 120:
#     print("You can ride the roller")
#     age = int(input("How old are you? "))
#     if age <= 12:
#         print("Child Tickets are $5")
#         ticket_price = 5
#     elif age <=18:
#         print("Youth Tickets are $7")
#         ticket_price = 7
#     elif 45 <= age <= 55:
#         print("Mid Life Tickets are $0")
#         ticket_price = 0
#     else:
#         print("Adult Tickets are $12")
#         ticket_price = 12
#
#     wants_photo = input("Do you want to have a photo take? Type y for Yes and n for No.")
#     if wants_photo == "y":
#         ticket_price += 3
#
#     print(f"Total Ticket Price is ${ticket_price}")
#
# else:
#     print("You can't ride the rollercoaster")
#
# # End

# # Task
#
# total_bill = None
#
# size = input("What size pizza do you want? S, M, or L: ")
# pepperoni = input("Do you want pepperoni on your pizza? Y or N: ")
# extra_cheese = input("Do you want extra cheese? Y or N: ")
#
# if size == "S" or size  == "s":
#     total_bill = 15
#     if pepperoni == "Y":
#         total_bill += 2
# elif size == "M" or size  == "m":
#     total_bill = 20
#     if pepperoni == "Y":
#         total_bill += 3
# elif size == "L" or size  == "l":
#     total_bill = 25
#     if pepperoni == "Y":
#         total_bill += 3
# else:
#     print("You typed the wrong inputs")
#
# if(extra_cheese == "Y" or extra_cheese == 'y'):
#     total_bill += 1
#
# print(f"The Total Bill is ${total_bill}")
#
# # End

# Project
print(
    r'''
*******************************************************************************
          |                   |                  |                     |
 _________|________________.=""_;=.______________|_____________________|_______
|                   |  ,-"_,=""     `"=.|                  |
|___________________|__"=._o`"-._        `"=.______________|___________________
          |                `"=._o`"=._      _`"=._                     |
 _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
|                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
|___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
          |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
 _________|___________| ;`-.o`"=._; ." ` '`."\ ` . "-._ /_______________|_______
|                   | |o ;    `"-.o`"=._``  '` " ,__.--o;   |
|___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
/______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
/______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
/______/______/______/______/______/______/______/______/______/______/_____ /
*******************************************************************************
'''
)
print("Welcome to Treasure Island.")
print("Your mission is to find the treasure.")

inpt = input(
    'You are at a cross road, Where do you want to go?\n   Type "left" or "right" \n'
).lower()

if inpt == "left":
    print("You've come to a lake. There is an island in the middle of the lake.")
    inpt = input(
        'Type "wait" to wait for a boat. Type "swim" to swim across. \n'
    ).lower()
    if inpt == "wait":
        print("You arrive at the island unharmed. There is a house with 3 doors.")
        inpt = input(
            "  One red, one yellow and one blue. Which colour do you choose?\n"
        ).lower()
        if inpt == "red":
            print("You have been burned by fire. Game Over.")
        elif inpt == "blue":
            print("You have been eaten by beasts. Game Over.")
        elif inpt == "yellow":
            print("You Win")
        else:
            print("You chose a door that does not exist. Game Over")
    else:
        print("You have been attacked by a trout. Game Over")
else:
    print("You have fallen into a hole. Game Over")

# End
