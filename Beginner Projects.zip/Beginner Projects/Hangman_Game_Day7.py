# # Project

# import random

# word_list = [
#     "abruptly",
#     "absurd",
#     "abyss",
#     "affix",
#     "askew",
#     "avenue",
#     "awkward",
#     "axiom",
#     "azure",
#     "bagpipes",
#     "bandwagon",
#     "banjo",
#     "bayou",
#     "beekeeper",
#     "bikini",
#     "blitz",
#     "blizzard",
#     "boggle",
#     "bookworm",
#     "boxcar",
#     "boxful",
#     "buckaroo",
#     "buffalo",
#     "buffoon",
#     "buxom",
#     "buzzard",
#     "buzzing",
#     "buzzwords",
#     "caliph",
#     "cobweb",
#     "cockiness",
#     "croquet",
#     "crypt",
#     "curacao",
#     "cycle",
#     "daiquiri",
#     "dirndl",
#     "disavow",
#     "dizzying",
#     "duplex",
#     "dwarves",
#     "embezzle",
#     "equip",
#     "espionage",
#     "euouae",
#     "exodus",
#     "faking",
#     "fishhook",
#     "fixable",
#     "fjord",
#     "flapjack",
#     "flopping",
#     "fluffiness",
#     "flyby",
#     "foxglove",
#     "frazzled",
#     "frizzled",
#     "fuchsia",
#     "funny",
#     "gabby",
#     "galaxy",
#     "galvanize",
#     "gazebo",
#     "giaour",
#     "gizmo",
#     "glowworm",
#     "glyph",
#     "gnarly",
#     "gnostic",
#     "gossip",
#     "grogginess",
#     "haiku",
#     "haphazard",
#     "hyphen",
#     "iatrogenic",
#     "icebox",
#     "injury",
#     "ivory",
#     "ivy",
#     "jackpot",
#     "jaundice",
#     "jawbreaker",
#     "jaywalk",
#     "jazziest",
#     "jazzy",
#     "jelly",
#     "jigsaw",
#     "jinx",
#     "jiujitsu",
#     "jockey",
#     "jogging",
#     "joking",
#     "jovial",
#     "joyful",
#     "juicy",
#     "jukebox",
#     "jumbo",
#     "kayak",
#     "kazoo",
#     "keyhole",
# ]


# character_state = [
#     r"""
#    |
#    |
# """,
#     r"""
#    |
#    |
#    O
# """,
#     r"""
#    |
#    |
#    O
#    |
# """,
#     r"""
#    |
#    |
#    O
#    |\
# """,
#     r"""
#    |
#    |
#    O
#   /|\
# """,
#     r"""
#    |
#    |
#    O
#   /|\
#     \
# """,
#     r"""
#    |
#    |
#    O
#   /|\
#   / \
# """,
# ]

# # s


# life = 0  # if hit 7, game end, character is hanged

# random_word = random.choice(word_list)
# random_word_length = len(random_word)
# selected_characters = set()
# found_characters = set()
# found_characters_length = 0

# print(random_word)


# for i in range(random_word_length):
#     print("_", end="")

# print()

# while life <= 6 and found_characters_length <= random_word_length - 1:
#     char_picked = input("Pick Letter from a to z: ").lower()

#     while (
#         len(char_picked) != 1
#         or not char_picked.isalpha()
#         or char_picked in selected_characters
#     ):
#         if char_picked in selected_characters:
#             print("You have already selected this character, please choose another one")
#         else:
#             print("You have given a wrong input. Please try later")
#         char_picked = input("Pick Letter from a to z: ")

#     selected_characters.add(char_picked)

#     if char_picked in random_word:
#         found_characters.add(char_picked)
#         found_characters_length += random_word.count(char_picked)
#         for letter in random_word:
#             if letter in found_characters:
#                 print(letter, end=" ")
#             else:
#                 print("_", end=" ")
#         print("\n")
#         if found_characters_length == random_word_length:
#             print("You Win, Word has been found")
#     else:
#         print("Wrong choice")
#         print("Character State is")
#         print(character_state[life])
#         if life == 6:
#             print("Game End, Character is hanged.")
#         life += 1

# # End
