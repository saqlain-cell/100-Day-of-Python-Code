# # My own made Project

# alphabet = [
#     "a",
#     "b",
#     "c",
#     "d",
#     "e",
#     "f",
#     "g",
#     "h",
#     "i",
#     "j",
#     "k",
#     "l",
#     "m",
#     "n",
#     "o",
#     "p",
#     "q",
#     "r",
#     "s",
#     "t",
#     "u",
#     "v",
#     "w",
#     "x",
#     "y",
#     "z",
# ]

# def encode(message_to_encode, shift_number):
#     placeholder = ""
#     for letter in message_to_encode:
#         if letter.isalpha():
#             placeholder += chr(ord(letter) + shift_number)
#         else:
#             placeholder += letter
#     print(placeholder)


# def decode(message_to_decode, shift_number):
#     placeholder = ""
#     for letter in message_to_decode:
#         if letter.isalpha():
#             character_ascii = ord(letter) - shift_number
#             if character_ascii < 97:
#                 character_ascii = 122 - ((97 - character_ascii) - 1)
#             placeholder += chr(character_ascii)
#         else:
#             placeholder += letter
#     print(placeholder)


# while True:
#     operation_encode_or_decode = input(
#         "Type 'encode' to encrypt and 'decode' to decrypt\n "
#     ).lower()

#     text = input("Type your message:\n").lower()
#     shift_number = int(input("Type the shift number:\n"))

#     if operation_encode_or_decode == "decode":
#         decode(text, shift_number)
#     else:
#         encode(text, shift_number)

#     message_to_go_again = input("Do you want to go again: ").lower()

#     if message_to_go_again != "yes":
#         print("GoodBye")
#         break

# # End

# # Instructor Made Project

# alphabet = [
#     "a",
#     "b",
#     "c",
#     "d",
#     "e",
#     "f",
#     "g",
#     "h",
#     "i",
#     "j",
#     "k",
#     "l",
#     "m",
#     "n",
#     "o",
#     "p",
#     "q",
#     "r",
#     "s",
#     "t",
#     "u",
#     "v",
#     "w",
#     "x",
#     "y",
#     "z",
# ]

# print(len(alphabet))


# def caesar(original_text, shift_amount, encode_or_decode):
#     output_text = ""
#     if encode_or_decode == "decode":
#         shift_amount *= -1

#     for letter in original_text:

#         if letter not in alphabet:
#             output_text += letter
#         else:
#             shifted_position = alphabet.index(letter) + shift_amount
#             shifted_position %= len(alphabet)
#             output_text += alphabet[shifted_position]
#     print(f"Here is the {encode_or_decode}d result: {output_text}")


# should_continue = True

# while should_continue:

#     direction = input("Type 'encode' to encrypt, type 'decode' to decrypt:\n").lower()
#     text = input("Type your message:\n").lower()
#     shift = int(input("Type the shift number:\n"))

#     caesar(text, shift, direction)

#     restart = input(
#         "Type 'yes' if you want to go again. Otherwise, type 'no'.\n"
#     ).lower()
#     if restart == "no":
#         should_continue = False
#         print("Goodbye")

# # End


# # Positional Arguments Vs KeyWord Arguments

# # When mixing both, positional arguments must come before keyword arguments


# def greet(name, age):
#     print(f"Hello, my name is {name}, and my age is {age}")


# greet("Saqlain", 20)
# greet(name="Ali", age=27)
# greet("Shoaib", age=25)

# # End

# # Coding Exercise 8

# def calculate_love_score(name1, name2):

#     combined_name = name1.lower() + name2.lower()

#     check_word_1 = "true"
#     check_word_2 = "love"

#     count_1 = 0
#     count_2 = 0

#     for letter in check_word_1:
#         count_1 += combined_name.count(letter)
#         print(f"{letter.capitalize()} occurs {combined_name.count(letter)} ")

#     for letter in check_word_2:
#         count_2 += combined_name.count(letter)
#         print(f"{letter.capitalize()} occurs {combined_name.count(letter)} ")

#     print(f"{count_1}{count_2}")


# calculate_love_score("Kanye West", "Kim Kardashian")

# # End
