# # Task

# """
# This is a
# multi-line string, can be used as a multiline comment if not assigned to anything

# """

# print(
#     """ We are
#       printing a multiline
#       String
#        """
# )

# # End

# # Task

# def format_name(f_name, l_name):
#     combined_name = f_name.replace(" ", "") + " " + l_name.replace(" ", "")
#     combined_name = combined_name.title()
#     return combined_name


# print(format_name("sAQlain", "   F    Aroo Q"))

# # End

# # Task

# def function_1(a):
#     if a == 1:
#         print(a)
#         # This would have given an error of missing return statement in java, but not in python

#     return "Nothing"


# # End


# # Task, Following Program is used to calculate whether a year is a leap year or not

# # Following are the conditions as to whether a year is leap one or not

# # - on every year that is divisible by 4 with no remainder

# # - except every year that is evenly divisible by 100 with no remainder

# # - unless the year is also divisible by 400 with no remainder

# # Following solution is correct, don't think it incorrect, it has passed all the test cases


# def is_leap_year(year):
#     if year % 4 == 0:

#         if year % 100 == 0:
#             if year % 400 == 0:
#                 return True

#             return False

#         return True
#     else:
#         return False


# # End


# # Task, this is used to explain as to what a Docstring is in python

# def acceleration_calculator(initial_velcoity, final_velocity, time_taken):
#     """This function is used
#     to calculate the acceleration of a car
#     """
#     acceleration = (final_velocity - initial_velcoity) / time_taken
#     print(acceleration)


# acceleration_calculator(70, 90, 5)

# # End

# Task

# def my_function(a):
#     if a < 40:
#         return
#         print(
#             "Terrible"
#         ),  # a statement after return will result in an error in java, but not in python
#     if a < 80:
#         return "Pass"
#     else:
#         return "Great"


# print(my_function(25))

# # End

# # Project, Calculator

# def add(n1, n2):
#     return n1 + n2


# def subtract(n1, n2):
#     return n1 - n2


# def multiply(n1, n2):
#     return n1 * n2


# def divide(n1, n2):
#     return n1 / n2


# operations = {"+": add, "-": subtract, "*": multiply, "/": divide}


# def calculator():
#     first_number = float(input("What's the first number? "))
#     should_accumulate = True

#     while should_accumulate:
#         for operation_symbol in operations:
#             print(operation_symbol)

#         operation = input("Pick an operation: ")
#         second_number = float(input("What's the next number? "))

#         result = operations[operation](first_number, second_number)

#         print(f"{first_number} {operation} {second_number} = {result}")

#         should_continue = input(
#             f"Type 'y' to continue calculating with {result}, or 'n' to start a new calculation"
#         )

#         if should_continue == "y":
#             first_number = result
#         else:
#             should_accumulate = False
#             print("\n" * 20)
#             calculator()


# calculator()

# # End
