import random

# Task
# fruits = [ "Apple", "Peach", "Pear"]
#
# for fruit in fruits:
#     print(f"The fruit present is {fruit}")
# End

# # Task

# student_scores = [150, 142, 185, 120, 171, 184, 149, 24, 59, 68, 199, 78, 65, 89, 86, 55, 91, 64, 89]
#
# highest_score = 0
# for score in student_scores:
#     if score > highest_score:
#         highest_score = score
#
# print(highest_score)


# total_exam_score = sum(student_scores)
# # The Python sum() function is a built-in tool that calculates the total of
# # all numeric items in an iterable (such as a list, tuple, or set) and
# # returns that total.
#
# print(total_exam_score)
#
# total_exam_score = 0
#
# for score in student_scores:
#     total_exam_score += score
# print(total_exam_score)
#
#
# # End

# Task
# student_scores_1 = [195, 142, 185, 120, 171, 184, 149, 24, 59, 68, 199, 78, 65, 89, 86, 55, 91, 64, 89]
# student_scores_2 = [150, 142, 115, 120, 171, 187, 149, 254, 59, 68, 199, 788, 65, 89, 86, 55, 91, 64, 89]
#
# print(max(student_scores_1))
# print(max(student_scores_1, student_scores_2))

# Python performs a lexicographical comparison to determine which list is "larger".
# The function then returns the entire list that is deemed the maximum.
# End

# # Task
# total = 0
#
# for i in range(1, 101):
#     total += i
# print(total)
# # End

# # Task, FizzBuzz Game
#
# for i in range(1,101):
#     if i % 3 == 0 and i % 5 == 0:
#         print("FizzBuzz")
#     elif i % 3 == 0:
#         print("Fizz")
#     elif i % 5 == 0:
#         print("Buzz")
#     else:
#         print(i)
#
# # End

# # Project
#
# letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
#            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
# numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
# symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']
#
# print("Welcome to the PyPassword Generator!")
# nr_letters = int(input("How many letters would you like in your password?\n"))
# nr_symbols = int(input(f"How many symbols would you like?\n"))
# nr_numbers = int(input(f"How many numbers would you like?\n"))
#
# total_characters_in_password = nr_letters + nr_symbols + nr_numbers
#
# characters_selected_from_lists  = []
#
# for i in range(nr_letters):
#     characters_selected_from_lists.append(random.choice(letters))
#
# for i in range(nr_symbols):
#     characters_selected_from_lists.append(random.choice(symbols))
#
# for i in range(nr_numbers):
#     characters_selected_from_lists.append(random.choice(numbers))
#
# print(characters_selected_from_lists)
# random.shuffle(characters_selected_from_lists)
# print(characters_selected_from_lists)
#
# password = ""
#
# for password_character in characters_selected_from_lists:
#     password += password_character
#
# print(f"Your Password is: {password}")
#
# # End
