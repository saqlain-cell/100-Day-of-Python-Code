# some_dict = {
#     1: "Saqlain Farooq",
#     37: "Shoaib Akhter",
#     39: "Lionel Messi",
#     4: "Khabib Nurmagomedov",
#     8: "Shahid Sultan",
#     15: "Akram Sajjad",
# }

# # for key, value in some_dict.items():
# #     print(f"{key}: {value}")

# # or more simpler method

# for key in some_dict:
#     print(f"{key}: {some_dict[key]} ")


# some_dict[22] = "Mike Tyson"  # This will simply add a new entry

# some_dict[37] = "Lauren Bell"  # This will overwrite the previous entry

# # Task

# student_scores = {"Harry": 88, "Ron": 78, "Hermione": 95, "Draco": 75, "Neville": 60}

# student_grades = {}

# for key in student_scores:

#     score = student_scores[key]

#     grade = ""

#     if 91 <= score <= 100:
#         grade += "Outstanding"
#     elif 81 <= score <= 90:
#         grade += "Exceeds Expectations"
#     elif 71 <= score <= 80:
#         grade += "Acceptable"
#     elif score <= 70:
#         grade += "Fail"

#     student_grades[key] = grade


# for key in student_grades:
#     print(f"{key}: {student_grades[key]}")

# # End


# # Task

# travel_log_1 = {
#     "France": ["Paris", "Lille", "Dijon"],
#     "Germany": ["Berlin", " Stuttgart", "Munich"],
# }

# print(travel_log_1["France"][1])


# nested_list = ["A", "B", ["C", "D"]]

# print(nested_list[2][1])

# travel_log_2 = {
#     "France": {"cities_visited": ["Paris", "Lille", "Dijon"], "total_visits": 12},
#     "Germany": {
#         "cities_visited": ["Berlin", "Hamburg", "Stuttgart"],
#         "total_visits": 5,
#     },
# }

# print(travel_log_2["Germany"]["cities_visited"][2])

# # End


# # Task

# starting_dictionary = {
#     "a": 9,
#     "b": 8,
# }


# final_dictionary = {
#     "a": 9,
#     "b": 8,
#     "c": 7,
# }

# final_dictionary = starting_dictionary += {"C":7}

# print(final_dictionary)
# # End


# Project
bidders = {}

while True:
    name = input("What is your name? ")
    bid = int(input("What is your bid? $"))

    bidders[name] = bid

    other_bidders_check = input("Are there any other bidders? Type 'yes' or 'no'\n")

    if other_bidders_check == "no":
        break

    print("\n" * 100)

highest_bidder_name = ""
highest_bidding_amount = 0

for key in bidders:
    if bidders[key] >= highest_bidding_amount:
        highest_bidder_name = key
        highest_bidding_amount = bidders[key]

print(
    f"The highest bidder is {highest_bidder_name} with amount ${highest_bidding_amount}"
)


# End
