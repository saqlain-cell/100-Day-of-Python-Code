import random

# # Task
# import my_module  # used to show as to how to use a self-created module
#
# random_integer = random.randint(1,100)
#
# random_float_0_to_1 = random.random()
#
# random_float_1_to_100 = random.uniform(1,100)
#
# print(random_float_1_to_100)
# # End

# random_number = (random.random()*10) % 2
#
# print(random_number)

# if random_number == 0:
#     print("It is heads")
# else:
#     print("It is tails")

# # Task
# random_float = random.uniform(0, 10) # This generates a random
# # floating point number b/w 0(inclusive) and 10(inclusive)
#
# print(random_float)
# # End

# # Task, Creating a Head or Tails Program
#
# random_heads_or_tails = random.randint(0, 1)
#
# if random_heads_or_tails == 0:
#     print("Tail")
# elif random_heads_or_tails == 1:
#     print("Head")
#
# # End

# # Task
# states_of_USA = ["Delaware", "Pennsylvania", "New Jersey", "Georgia", "Connecticut"]
# print(states_of_USA[1])
# print(states_of_USA[2])
# print(states_of_USA[3])
# print(states_of_USA[-1]) # When we give a negative index, it starts counting from the end of the list
# print(states_of_USA[-2])
# print(states_of_USA[-3])
# print(states_of_USA[-5])
#
# states_of_USA[1] = "Rawalpindi"
# print(states_of_USA[1])
#
# states_of_USA.append("Saki Empire")
# print(states_of_USA[-1])
# print(states_of_USA[-2])
#
# states_of_USA.extend(["new delhi" , "Tel Aviv", "Paris" ])
# print(states_of_USA[-1])
# print(states_of_USA[-2])
# print(states_of_USA[-3])
#
# # End

# # Task, Who will pay the bill?
#
# friends = ["Alice", "Bob", "Charlie", "David", "Emanuel"]
# random_index = random.randint(0, len(friends)-1)
# print(friends[random_index])
#
# # or another way
# friends = ["Alice", "Bob", "Charlie", "David", "Emanuel"]
# print(random.choice(friends))
# # End

# # Task
# nested_list_1 = ["Saki", "Salman", ["Imran", "Ayesha", "Ali"], "Omar", ["Arshad", "Arooj"]]
# print(nested_list_1 [2][1])
#
# fruits = ["Mango", "Apple", "Strawberry"]
# vegetables = ["Carrot", "Spinach", "Onion"]
#
# fruits_and_vegetables = [fruits, vegetables]
#
# print(fruits_and_vegetables)
# print(fruits_and_vegetables[0]) # this will give all the fruits
# print(fruits_and_vegetables[1]) # this will give all the vegetables
#
# # End

# Project, Rock Papers Scissors Game
rock = """
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
"""

paper = """
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
"""

scissors = """
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
"""

user_selected_choice = int(
    input("What do saki sahb choose? Type 0 for Rock, 1 for Paper, 2 for Scissors\n")
)
game_images = [rock, paper, scissors]

if 0 <= user_selected_choice <= 2:
    print(game_images[user_selected_choice])

computer_selected_choice = random.randint(0, 2)
print("Computer chose\n")
print(game_images[computer_selected_choice])

if user_selected_choice >= 3 or user_selected_choice < 0:
    print("You typed an invalid number. You lose!")
elif user_selected_choice == 0 and computer_selected_choice == 2:
    print("You win!")
elif computer_selected_choice == 0 and user_selected_choice == 2:
    print("You lose!")
elif computer_selected_choice > user_selected_choice:
    print("You lose!")
elif user_selected_choice > computer_selected_choice:
    print("You win!")
elif computer_selected_choice == user_selected_choice:
    print("It's a draw!")
# End
