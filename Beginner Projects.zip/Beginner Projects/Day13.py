import random

# # Task

# try:
#     print("This is a try block")

# except BaseException as e:
#     print(e)
# finally:
#     print("This is a finally block")

# # End

# # Task


# def add(n1, n2):
#     return n1 + n2


# def mutate(a_list):
#     b_list = []
#     new_item = 0
#     for item in a_list:
#         new_item = item * 2
#         new_item += random.randint(1, 3)
#         new_item = add(new_item, item)
#         b_list.append(new_item)

#     print(b_list)


# mutate([1, 2, 3, 5, 8, 13])

# # End


# # Task

# def is_leap(year):
#     if year % 4 == 0:
#         if year % 100 == 0:
#             if year % 4000 == 0:
#                 return True
#             else:
#                 return False
#         else:
#             return True
#     else:
#         return False


# print(is_leap(2000))

# # End
