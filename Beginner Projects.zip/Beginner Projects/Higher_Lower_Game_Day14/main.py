# # Project, This code is my own, it is similar to the instrcutor based code or project

# import game_data

# import random

# data = game_data.data

# logo = game_data.logo

# vs_logo = game_data.vs

# def select_celebrity(selected_celebrities_as_indicies):
#     rand_int = random.randint(0, len(data) - 1)

#     while rand_int in selected_celebrities_as_indicies:
#         rand_int = random.randint(0, len(data) - 1)

#     selected_celebrities_as_indicies.append(rand_int)

#     return data[rand_int]


# def check_answer(celebrity_A, celebrity_B, selected_choice):
#     if celebrity_A > celebrity_B and selected_choice == "a":
#         return True
#     elif celebrity_A < celebrity_B and selected_choice == "b":
#         return True

#     return False


# def format_celebrity_data(celebrity):
#     return f"{celebrity["name"]}, a {celebrity["description"]}, from {celebrity["country"]}"


# def game():
#     selected_celebrities_as_indicies = []
#     celebrity_B = select_celebrity(selected_celebrities_as_indicies)

#     result = True
#     score = 0
#     print(logo)

#     while result:
#         celebrity_A = celebrity_B
#         celebrity_B = select_celebrity(selected_celebrities_as_indicies)

#         print(f"Compare A: {format_celebrity_data(celebrity_A)}")
#         print(vs_logo)
#         print(f"Against B: {format_celebrity_data(celebrity_B)}")

#         selected_choice = input("Who has more followers? Type 'A' or 'B': ").lower()

#         result = check_answer(
#             celebrity_A["follower_count"],
#             celebrity_B["follower_count"],
#             selected_choice,
#         )

#         print("\n" * 20)
#         print(logo)

#         if result:
#             score += 1
#             print(f"Your answer is correct, your score is {score}")
#         else:
#             print("Sorry, that is wrong, your answer is incorrect")


# game()

# # End
