# print("It is a good country")
#
# # According to the Task, we have printed the following recipe
#
# print("1. Mix 500g of Flour, 10g Yeast and 300ml Water in a bowl.")
# print("2. Knead the dough for 10 minutes.")
# print("3. Add 3g of Salt.")
# print("4. Leave to rise for 2 hours.")
# print("5. Bake at 200 degrees C for 30 minutes.")

# # \n creates a new line
# print("Hell, this is Saki.\nHe is from Pakistan")

# # String Concatentation
# username = input("What is your name\n")
# print(f"The username is {username}")

# # Another Method
# print("Hello " + input("What is your name?\n") + "!")

# # The subsequent is used to calculate the length of the string
# print("The length of the string is " + str(len(input("Give String: "))))

# # Project

# print("Welcome to the Band Name Generator")
# city_name = input("What's the name of the city you grew up in?\n")
# pet_name = input("What's your pet name?\n")
# print(f"Your Band name could be: {city_name} {pet_name}")
