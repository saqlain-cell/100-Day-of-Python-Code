from turtle import Turtle
from player import Player

FONT = ("Courier", 24, "normal")


class Scoreboard(Turtle):

    def __init__(self, turtle_window):
        super().__init__()
        self.shape("blank")
        self.penup()
        self.goto(-(turtle_window.window_width() / 2) + 90, (turtle_window.window_height() / 2) - 40)
        self.update_scoreboard(0)

    def update_scoreboard(self, player_level):
        self.clear()
        self.write(f"Level: {player_level}", move=False, align='center', font=FONT)

    def game_over(self):
        self.goto(0, 0)
        self.write(f"GAME OVER", align="center", font=FONT)
