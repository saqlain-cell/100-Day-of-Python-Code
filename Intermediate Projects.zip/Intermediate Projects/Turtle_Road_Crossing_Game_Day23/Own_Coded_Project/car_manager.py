from turtle import Turtle
import random

COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
MOVE_DISTANCE = 5
MOVE_INCREMENT = 10


class CarManager:
    def __init__(self, car_window):
        self.level = 0
        self.all_cars = []
        self.window = car_window
        self.move_distance = MOVE_DISTANCE

    def increase_level(self):
        self.level += 1
        self.move_distance += MOVE_INCREMENT

    def get_level(self):
        return self.level

    def move_cars(self):
        for car in self.all_cars[:]:  # We created a copy of the list, the detail of this is present on
            # python notebook register page no. 124 as to why we have done so.
            car.forward(self.move_distance)
            if car.xcor() < -(self.window.window_width() / 2) + 30:
                car.hideturtle()  # We need to hide the turtle, because even if we remove the object from list, it still remains in python turtle graphics memory
                self.all_cars.pop(
                    self.all_cars.index(car))  # This effectively removes the car element when it goes out of the screen

    def check_collision(self, player):
        for car in self.all_cars:
            if player.distance(car) < 20:
                return False
        return True

    def create_car(self):
        random_chance = random.randint(1, 6)
        if random_chance == 1:
            new_car = Turtle("square")
            new_car.penup()
            new_car.color(random.choice(COLORS))
            new_car.shapesize(stretch_wid=1, stretch_len=3)
            new_car.left(180)
            random_y = random.uniform((-(self.window.window_height() / 2) + 50), self.window.window_height() / 2 - 20)
            new_car.goto(self.window.window_width() / 2, random_y)
            self.all_cars.append(new_car)
