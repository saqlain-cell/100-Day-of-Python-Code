import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard
from turtle import Turtle

window = Screen()
window.setup(width=600, height=600)
window.tracer(0)

player = Player()
scoreboard = Scoreboard(window)
car_manager = CarManager(window)

window.listen()
window.onkey(player.move, "Up")

game_is_on = True
while game_is_on:

    time.sleep(0.1)
    window.update()
    car_manager.create_car()
    car_manager.move_cars()

    if player.ycor() > (window.window_height() / 2) - 20:
        player.reset()
        car_manager.increase_level()
        scoreboard.update_scoreboard(car_manager.get_level())

    if not car_manager.check_collision(player):
        game_is_on = False
        scoreboard.game_over()

window.exitonclick()
