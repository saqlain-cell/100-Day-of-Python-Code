import turtle
from paddle import Paddle
from scoreboard import Scoreboard
from ball import Ball
import time

window = turtle.Screen()
window.bgcolor("black")
window.setup(width=800, height=600)
window.title("Saqlain's Pong Game")
window.tracer(0)

ball = Ball()
paddle_offset = 50
paddle_left_position = (-(window.window_width() / 2) + paddle_offset, 0)
paddle_left = Paddle(paddle_left_position, window)
paddle_right_position = ((window.window_width() / 2) - paddle_offset, 0)
paddle_right = Paddle(paddle_right_position, window)
scoreboard = Scoreboard(window)

window.listen()
window.onkeypress(paddle_left.go_up, "w")
window.onkeypress(paddle_left.go_down, "s")
window.onkeypress(paddle_right.go_up, "Up")
window.onkeypress(paddle_right.go_down, "Down")

is_game_on = True

while is_game_on:
    window.update()
    ball.move()

    # when hits top walls
    if not (-(window.window_height() / 2) + 17.5 < ball.ycor() < (window.window_height() / 2) - 17.5):
        ball.bounce_y()

    # Detect Left paddle miss
    if ball.xcor() < -(window.window_width() / 2) + 17.5:
        scoreboard.increase_right_paddle_score()
        ball.reset_position()

    # Detect right paddle miss
    if ball.xcor() > (window.window_width() / 2) - 17.5:
        scoreboard.increase_left_paddle_score()
        ball.reset_position()

    check_offset = paddle_offset + 20

    # Right paddle collision
    if ball.distance(paddle_right) < 45 and ball.xcor() > (window.window_width() / 2) - 70:
        ball.bounce_x()

    # Left paddle collision
    if ball.distance(paddle_left) < 45 and ball.xcor() < -(window.window_width() / 2) + 70:
        ball.bounce_x()

    time.sleep(ball.move_speed)

window.exitonclick()
