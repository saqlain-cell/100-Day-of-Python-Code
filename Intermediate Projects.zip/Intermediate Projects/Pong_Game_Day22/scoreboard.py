import turtle
from turtle import Turtle


class Scoreboard(Turtle):

    def __init__(self, score_window):
        super().__init__()
        self.left_paddle_score = 0
        self.right_paddle_score = 0
        self.shape("blank")
        self.penup()
        self.color("white")
        self.goto((score_window.window_width() / 2) - 70, (score_window.window_height() / 2) - 40)
        self.update_scoreboard()

    def update_scoreboard(self):
        self.clear()
        self.write(f"{self.left_paddle_score} : {self.right_paddle_score}", move=False, align='center',
                   font=('Arial', 26, 'normal'))

    def increase_left_paddle_score(self):
        self.left_paddle_score += 1
        self.update_scoreboard()

    def increase_right_paddle_score(self):
        self.right_paddle_score += 1
        self.update_scoreboard()
