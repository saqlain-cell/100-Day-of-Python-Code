from turtle import Turtle


class Paddle(Turtle):
    def __init__(self, position, paddle_window):
        super().__init__()
        self.window = paddle_window
        self.shape("square")
        self.color("white")
        self.shapesize(stretch_wid=5, stretch_len=1)
        self.penup()
        self.goto(position)

    def go_up(self):
        if self.ycor() < (self.window.window_height() / 2) - 60:
            new_y = self.ycor() + 20
            self.goto(self.xcor(), new_y)

    def go_down(self):
        if self.ycor() > -(self.window.window_height() / 2) + 60:
            new_y = self.ycor() - 20
            self.goto(self.xcor(), new_y)
