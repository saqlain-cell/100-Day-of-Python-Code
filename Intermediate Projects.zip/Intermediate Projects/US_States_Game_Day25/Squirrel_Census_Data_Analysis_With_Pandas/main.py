# The Explanation of this code is present on notebook page no. 135

import pandas

squirrel_data = pandas.read_csv("2018_Central_Park_Squirrel_Census_-_Squirrel_Data.csv")

total_grey_squirrels = squirrel_data[squirrel_data["Primary Fur Color"] == "Gray"]["Primary Fur Color"].count()
total_red_squirrels = squirrel_data[squirrel_data["Primary Fur Color"] == "Cinnamon"]["Primary Fur Color"].count()
total_black_squirrels = squirrel_data[squirrel_data["Primary Fur Color"] == "Black"]["Primary Fur Color"].count()

total_grey_squirrels_way_1 = (squirrel_data["Primary Fur Color"] == "Gray").sum()  # This one is more cleaner
total_grey_squirrels_way_2 = len(
    squirrel_data[squirrel_data["Primary Fur Color"] == "Gray"])  # This one is more cleaner

# The code in total_grey_squirrels_way_2 is the instructor code, teacher has done it this way.

data_dict = {
    "Fur Colour": ["grey", "red", "black"],
    "Count": [total_grey_squirrels, total_red_squirrels, total_black_squirrels]
}

resultant_DataFrame = pandas.DataFrame(data_dict)
resultant_csv = resultant_DataFrame.to_csv("squirrel_count.csv")
