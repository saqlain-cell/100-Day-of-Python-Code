# # Task 1, My own code
# # What we have essentially done in the following is that
# # we have skipped the first line in the fetched data
# # because it contains only the headers of the data
# # which is not relevant. So, we have only added the actual
# # data lines as strings in the list.
# data = []
# with open("weather_data.csv") as weather_data_file:
#     next(weather_data_file)  # This skips the first line
#     for line in weather_data_file:
#         cleaned_line = line.strip("\n")
#         data.append(cleaned_line)
#
# print(data)
# # End

# # Task 1
# # Instructor based code task
# data = []
# with open("weather_data.csv") as weather_data_file:
#     lines = weather_data_file.readlines()
#     for line in lines[1:]:
#         cleaned_line = line.strip()
#         print(cleaned_line)
# # End


# # Task 2
# # As We have seen that the csv data to read and work with is very difficult.
# # So, we use CSV library which will itself clean and manage the data for us.
# # That is why CSV library import is used. Its implementation is showed in the following.
#
# import csv  # First we need to import the CSV file.
#
# with open("weather_data.csv") as data_file:
#     data = csv.reader(data_file)
#     for row in data:
#         print(row)
#
# # With CSV, there is no need to strip the newline characters from the end.
# # Additionally, we can see that it has converted each line into a separate list for us.
# # End


# # Task 3, this task is further taken from task 2
#
# import csv
#
# with open("weather_data.csv") as data_file:
#     data = csv.reader(data_file)
#     temperatures = []
#     next(data)
#     for row in data:
#         temperatures.append(int(row[1]))
#
# print(temperatures)
#
# # End

# # Task 4
# # Important Point:
# # While the csv library is the built-in library for reading and managing
# # csv files. It requires a lot of code to handle data which does not work
# # well for large data. So, for this purpose, we will use Pandas Library.
# # Pandas Library is not in-built, so we have to manually download it first.
#
# import pandas  # Now, we can successfully import it.
#
# data = pandas.read_csv("weather_data.csv")
#
# print(data)  # We can see as to how beautifully the data is formatted
#
# print(type(data))  # This will print out the type to be a DataFrame. A Data Frame is a tabular one like XL sheet or google sheets.
#
# # End


# # Task 5, This is a further version of task 4
#
# import pandas  # Now, we can successfully import it.
#
# data = pandas.read_csv("weather_data.csv")
#
# print(data["temp"])  # we can see that there is no need to create first list for the "temp", and then display the data
#
# for temp in data["temp"]:
#     print(temp)
#
# print(type(data["temp"]))  # This will print out the type to be a Series one.
#
# # End


# # Task 6
#
# import pandas
#
# weather_data = pandas.read_csv("weather_data.csv")
# weather_data_dict = weather_data.to_dict()
#
# # print(weather_data_dict)
#
# weather_data_temp_list = weather_data["temp"].to_list()
# # print(weather_data_temp_list)
#
# # in the following method we will calculate the average temperature taking into account all the days.
# # Inner Task
# sum_of_temp_of_days = sum(weather_data_temp_list)
# count_of_days = len(weather_data_temp_list)
# average = sum_of_temp_of_days // count_of_days
#
# # print(average)
#
# # or more simply, we can use the pandas mean() method to calculate the average, mean refers to average.
#
# print(f"Average: {weather_data["temp"].mean()}")  # for the pandas mean() method to work,
# # we have to use the actual pandas Series datatype instead of a python list.
#
# print(f"Max Temperature Recorded For Days: {weather_data["temp"].max()}")
# # Inner Task End
#
# # End

# # Task 7
# import pandas
#
# weather_data = pandas.read_csv("weather_data.csv")
# print(weather_data["condition"])
# print(weather_data.condition)
#
# # Both of these statements are correct for accessing the data.
# # The type of both these datatypes will be a Pandas Series datatype.
#
# # End


# # Task 8
# # This task explains as how to get a particular row from the pandas dataframe.
# import pandas
#
# weather_data = pandas.read_csv("weather_data.csv")
#
# print(weather_data[weather_data["day"] == "Monday"])
#
# # Inner Task
# # This task get the row of data where the temperature is the maximum from the dataframe.
# print(weather_data[weather_data["temp"] == weather_data["temp"].max()])
# print(weather_data[weather_data.temp == weather_data.temp.max()])
# # Both the above lines mean the same thing, the second one is a little bit more cleaner.
# # Inner Task End
#
# # Inner Task
# print("-----------Task------------")
# monday = weather_data[weather_data.day == "Monday"]
# print(monday)
# print(monday.condition)
# print(type(monday.temp))  # Important Note: This is also a pandas Series datatype.
# print(monday.temp[0])  # This is how to get the actual data itself by excluding the series.
# print(type(monday.temp[0]))  # This shows the datatype to be an integer.
# monday_temp_in_fahrenheit = (monday.temp[0] * 1.8) + 32
# print(monday_temp_in_fahrenheit)
# # Inner Task End
#
# # End


# # Task 9
# # This shows as to how to create a pandas dataframe from scratch, and consequently
# # convert that DataFrame or any other DataFrame to a CSV file.
# import pandas
#
# data_dict = {
#     "students": ["Amy", "James", "Angela"],
#     "scores": [76, 56, 65],
# }
# data = pandas.DataFrame(data_dict)
# csv_file = data.to_csv("new_data.csv")  # We can convert the above DataFrame or any other Dataframe file to a CSV file.
#
# # So, we can get an idea as to how powerful this pandas library is.
# # End
