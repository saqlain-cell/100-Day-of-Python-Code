import pandas


def format_word(word_to_format):
    return word_to_format.replace("\n", "").upper()


nato_phonetic_dataframe = pandas.read_csv("nato_phonetic_alphabet.csv")
nato_phonetic_dictionary = {row.letter: row.code for (index, row) in
                            nato_phonetic_dataframe.iterrows()}  # A dictionary comprehension

word = input("Word: ")

word = format_word(word)

nato_phonetic_list = [nato_phonetic_dictionary[letter] for letter in word]  # A list comprehension

print(nato_phonetic_list)
