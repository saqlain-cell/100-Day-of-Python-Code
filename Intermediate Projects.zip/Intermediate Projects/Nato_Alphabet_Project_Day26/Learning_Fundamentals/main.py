# # Task
#
# numbers = [2, 3, 4]
# new_list = [item + 1 for item in numbers]
# print(new_list)
# name = "Saqlain"
# new_list = [letter for letter in name]
# print(new_list)
# new_list = [num * 2 for num in range(1, 5)]
# print(new_list)
# new_list = [num for num in range(1, 4) if num % 2 == 0]
# print(new_list)
# new_list = [num for num in range(1, 5) if num % 2 == 0]
# print(new_list)
# names = ["Alex", "Beth", "Caroline", "Dave", "Elanor", "Freddie"]
# short_names = [name for name in names if len(name) < 5]
# print(short_names)
# long_names_capitalized = [name.upper() for name in names if len(name) >= 5]
# print(long_names_capitalized)
#
# # End
import pandas

# # Task
# numbers = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
# squared_numbers = [num ** 2 for num in numbers]
# print(squared_numbers)
# # End

# # Task
# # This task first list of string to numbers lists and then filters out
# # only the even numbers and shows them in the console.
# list_of_strings = ['9', '0', '32', '8', '2', '8', '64', '29', '42', '99']
# numbers = [int(string) for string in list_of_strings]
# result = [num for num in numbers if num % 2 == 0]
# print(result)
# # End

# # Task
# # What the following task is doing is that it read lines from both the text files
# # and stores them in their respective lists by first string the newline characters
# # from the read lines and then converting those strings into integers and then
# # stores them into their respective lists. At the end, what it does is that it
# # finds the numbers that are common in both the list or in both the files, and then
# # creates a result list that contains those numbers.
#
# with open("file1.txt") as file_1:
#     file_1_numbers_list = [int(line.rstrip("\n")) for line in file_1.readlines()]
#
# with open("file2.txt") as file_2:
#     file_2_numbers_list = [int(line.rstrip("\n")) for line in file_2.readlines()]
#
# result = [num for num in file_1_numbers_list if num in file_2_numbers_list]
#
# # End


# # Dictionary Comprehensions
# # Task
# # Following is a dictionary comprehensions,
# # What we have essenetially done in the following task is that we have a list of students,
# # and from that list we create a dictionary compreshension where each of the student in the list
# # is assigned a random number between 1 and 100(both including), and then we use the resultant
# # dictionary comprehension to create another dictionary comprehension which contains only the
# # students whose scores are equal to or greater than 60. Remember that the list will change each time
# # because we are using the random module.
# import random
#
# students = ['Alex', 'Beth', 'Caroline', 'Dave', 'Elanor', 'Freddie']
# students_scores = {student: random.randint(1, 100) for student in students}
# students_passed = {student: student_score for (student, student_score) in students_scores.items() if
#                    student_score >= 60}
# print(students_scores)
# print(students_passed)
# # End


# # Task
# # The following break downs a sentence into a list of words,
# # Then it creates a dictionary where each word as a key and
# # its corresponding length as a value.
# sentence = "What is the Airspeed Velocity of an Unladen Swallow?"
#
# splited_sentence = sentence.split()  # This method splits the sentence into a list of words
#
# splited_sentence_word_length_count = {word: len(word) for word in splited_sentence}
#
# # End


# # Task
#
# weather_c = {"Monday": 12, "Tuesday": 14, "Wednesday": 15, "Thursday": 14, "Friday": 21, "Saturday": 22, "Sunday": 24}
#
# weather_f = {day: (temp_in_celsius * 9 / 5) + 32 for (day, temp_in_celsius) in weather_c.items()}
#
# print(weather_f)
#
# # End

# # Task
#
# # Following is the method to iterate over a dictionary
#
# student_dict = {
#     "student": ["Angela", "James", "Lilly"],
#     "score": [56, 76, 98]
# }
#
# for (key, value) in student_dict.items():
#     print(key, value)
#
# # Following is a way to iterate over a pandas DataFrame
# # A pandas DataFrame is very much like a python dictionary
#
# print("-------------Pandas DataFrame----------------------")
# student_data_frame = pandas.DataFrame(student_dict)
# print(student_data_frame)
#
# for (key, value) in student_data_frame.items():
#     print(key)
#
# for (key, value) in student_data_frame.items():
#     print(value)
#
# print("-----------End--------------")
# # We can see from the above loops that the DataFrame iterated are basically the same,
# # so this is not very much efficient because it provides us the same output as the for
# # in loop implemented on a python dictionary. The solution to this problem is a pandas
# # iterrows() which is implemented as follows:
#
# for (index, row) in student_data_frame.iterrows():
#     print(row)
# # As we can see from the above loop that each row
# # with its column specification is printed.
#
# print("-------------End------------------")
# # Following is a way that show the specifed column entry for each row by using the loop
#
# for (index, row) in student_data_frame.iterrows():
#     print(row.student)
#
# for (index, row) in student_data_frame.iterrows():
#     print(row.score)
#
# print("--------------End-----------------")
#
# # End
