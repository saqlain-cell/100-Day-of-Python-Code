# This contains the same code from the Day 25 my own code project,
# the only difference is that where we need to create list from previous
# lists, we use list comprehensions to fulfill this purpose.


# Important Point: The reason we have chosen a gif image rather than a png,
# or jpeg one because the turtle module works only with gif images.

# The changing is made only in the line no. 61

import turtle
import pandas

GAME_WIN_FONT = ("Courier", 16, "normal")
STATE_APPEND_FONT = ("Courier", 8, "normal")


def format_state_name(state_name):
    if state_name is None:
        return None
    state_name = state_name.title()
    state_name = state_name.strip(" ")
    return state_name


def show_game_complete_message(window):
    message = turtle.Turtle()
    message.hideturtle()
    message.penup()
    message.goto(-(window.window_width() / 2) + 20, (window.window_height() / 2) - 50)
    message.write(f"You Win, all states have been guessed", move=False, align='left', font=GAME_WIN_FONT)


def mark_map(state_name, x_coordinate, y_coordinate):
    state_pinpoint = turtle.Turtle()
    state_pinpoint.hideturtle()
    state_pinpoint.penup()
    state_pinpoint.goto(x_coordinate, y_coordinate)
    state_pinpoint.write(f"{state_name}", move=False, align='center', font=STATE_APPEND_FONT)


data = pandas.read_csv("50_states.csv")

all_states = data["state"].to_list()

window = turtle.Screen()
window.setup(725, 700)
window.bgpic("blank_states_img.gif")

given_state_name = turtle.textinput("US state Game", "Give state name")
states_guessed = []
states_guessed_count = 0
is_game_on = True

while is_game_on:
    given_state_name = format_state_name(given_state_name)
    if given_state_name is None or given_state_name == "Exit":  # This handles the case when user presses cancel
        is_game_on = False

        # The changing is made only in the following line
        missing_states = [state for state in all_states if state not in states_guessed]

        new_data = pandas.DataFrame(missing_states)
        new_data.to_csv("states_to_learn.csv")

    elif given_state_name in all_states:
        if given_state_name in states_guessed:
            given_state_name = turtle.textinput("US state Game", "Already Guessed, give another!")
        else:
            states_guessed.append(given_state_name)
            states_guessed_count += 1

            given_state_name_x_coordinates = (data[data["state"] == given_state_name]["x"]).item()
            given_state_name_y_coordinates = (data[data["state"] == given_state_name]["y"]).item()

            mark_map(given_state_name, given_state_name_x_coordinates, given_state_name_y_coordinates)

            if states_guessed_count >= 50:
                show_game_complete_message(window)
                is_game_on = False
            else:
                given_state_name = turtle.textinput("US state Game", "Correct, give another state name!")
    else:
        given_state_name = turtle.textinput("US state Game", "Wrong, try again!")

window.exitonclick()
