# import turtle  # This is a built-in module of python that we have imported, We are going to use this module to create a class
# timmy = (
#     turtle.Turtle()
# )  # This is not a function that we are calling from turtle module, but rather it is a class that we are using to create an object, so timmy is an object

# print(timmy)  # when we print this, the terminal tells us that this is an object.

# # Object attributes simply means the object's variables

# my_screen = (
#     turtle.Screen()
# )  # The "Screen" is also a class here that we have used from turtle module, it is the screen on which the turtle object will show up

# # Task, Following shows how to get the attribute(variable) of an object, process is similar to java

# print(my_screen.canvheight)

# # End


# # Task, Following shows how to get the method of an object, process is similar to java

# timmy.shape("turtle")
# timmy.color("lightseagreen")
# timmy.forward(100)
# timmy.left(90)
# timmy.forward(100)
# timmy.right(45)
# timmy.forward(100)
# timmy.right(135)
# timmy.forward(300)
# my_screen.exitonclick()


# # End

# # Task

# from prettytable import PrettyTable  # PrettyTable is a class here

# table = (
#     PrettyTable()
# )  # this is a class that we have used from the package, don't mistake it to be a function

# table.add_column("Pokemon", ["Pikachu", "Squirtle", "Charmander"])
# table.add_column("Type", ["Electric", "Water", "Fire"])

# print(table)

# table.padding_width = 10

# print(table)

# table.align = "r"

# print()

# print(table)

# # End


# # Project,
#
# from menu import Menu
# from coffee_maker import CoffeeMaker
# from money_machine import MoneyMachine
#
# menu = Menu()
# coffee_maker = CoffeeMaker()
# money_machine = MoneyMachine()
#
# is_on = True
#
#
# while is_on:
#     options = menu.get_items()
#     choice = input(f"What would you like? ({options}): ")
#
#     if choice == "off":
#         is_on = False
#     elif choice == "report":
#         coffee_maker.report()
#         money_machine.report()
#     else:
#         drink = menu.find_drink(choice)
#
#         if coffee_maker.is_resource_sufficient(drink) and money_machine.make_payment(
#             drink.cost
#         ):
#             coffee_maker.make_coffee(drink)
#
#
# # End
