import random

# # Task, Etch a Sketch Challenge
#
# import turtle as turtle_module
#
# turtle = turtle_module.Turtle()
# window = turtle_module.Screen()
#
# def move_turtle_forwards():
#     turtle.forward(5)
#
#
# def move_turtle_backwards():
#     turtle.backward(5)
#
#
# def rotate_counter_clockwise():
#     turtle.left(10)
#
#
# def rotate_clockwise():
#     turtle.right(10)
#
#
# def clear_window():
#     turtle.clear()
#     turtle.penup()
#     turtle.home()
#     turtle.pendown()
#
#
# window.onkey(move_turtle_forwards, "w")
# window.onkey(move_turtle_backwards, "s")
# window.onkey(rotate_counter_clockwise, "a")
# window.onkey(rotate_clockwise, "d")
# window.onkey(clear_window, "c")
# window.listen()
#
# window.exitonclick()
# # End

# # Code No. 1
# # Project Practice, My Own Code, Important Note: My Own Code is better than the instructor
# import turtle as turtle_module
#
# window = turtle_module.Screen()
# window.setup(width=500, height=400), this is used to setup the dimensions of the window according to your need
# in the above line of code, it is recommended to use keyword arguments rather than positional arguments

# colors_list = ["red", "orange", "yellow", "green", "blue", "purple"]
# all_turtles = []
#
#
# def create_turtles(colors, turtles_list):
#     for i in range(len(colors)):
#         new_turtle = turtle_module.Turtle("turtle")
#         new_turtle.penup()
#         new_turtle.color(colors[i])
#         turtles_list.append(new_turtle)
#
#     return turtles_list
#
#
# def line_up_turtles(turtles_list):
#     prev_turtle_y_coordinates = window.window_height() // 2
#     for turtle in turtles_list:
#         current_turtle_y_coordinates = prev_turtle_y_coordinates - 50
#         turtle.goto(-(window.window_width() / 2) + 20, current_turtle_y_coordinates)
#         prev_turtle_y_coordinates = current_turtle_y_coordinates
#
#
# def start_race(turtles_list):
#     user_bet = window.textinput(title="Make your bet", prompt="Which turtle will win the race? Enter a color: ")
#     is_race_on = False
#     if user_bet:
#         is_race_on = True
#
#     while is_race_on:
#         for turtle in turtles_list:
#             if turtle.xcor() >= (window.window_width() // 2) - 30:
#                 is_race_on = False
#                 winning_turtle = turtle.pencolor()
#                 if winning_turtle == user_bet:
#                     print(f"You've Won, the {winning_turtle} turtle has won the race")
#                 else:
#                     print(f"You've Lost, the {winning_turtle} turtle has lost the race")
#                 break
#
#             turtle.forward(random.randint(0, 10))
#
#
# all_turtles = create_turtles(colors_list, all_turtles)
# line_up_turtles(all_turtles)
# start_race(all_turtles)
#
# window.exitonclick()
# # End

# Code No. 2

# # Project, Instructor Code
#
# from turtle import Turtle, Screen
# import random
#
# is_race_on = False
# window = Screen()
# window.setup(width=500, height=400)
# user_bet = window.textinput(title="Make your bet", prompt="Which turtle will win the race? Enter a color: ")
# colors = ["red", "orange", "yellow", "green", "blue", "purple"]
# all_turtles = []
#
#
# def line_up_turtles(turtles):
#     x_coordinates = -(window.window_width() / 2) + 50
#     prev_turtle_y_coordinates = (window.window_height() / 2)
#     for turtle_in_race in turtles:
#         current_turtle_y_coordinates = prev_turtle_y_coordinates - 50
#         turtle_in_race.goto(x_coordinates, current_turtle_y_coordinates)
#         prev_turtle_y_coordinates = current_turtle_y_coordinates
#
#
# # Create 6 turtles
# for turtle_index in range(0, 6):
#     new_turtle = Turtle(shape="turtle")
#     new_turtle.penup()
#     new_turtle.color(colors[turtle_index])
#     all_turtles.append(new_turtle)
#
# line_up_turtles(all_turtles)
#
# if user_bet:
#     is_race_on = True
#
# while is_race_on:
#     for turtle in all_turtles:
#         # 230 is 250 - half the width of the turtle.
#         if turtle.xcor() >= window.window_width() / 2 - 35:
#             is_race_on = False
#             winning_color = turtle.pencolor()
#             if winning_color == user_bet:
#                 print(f"You've won! The {winning_color} turtle is the winner!")
#             else:
#                 print(f"You've lost! The {winning_color} turtle is the winner!")
#
#         # Make each turtle move a random amount.
#         rand_distance = random.randint(0, 10)
#         turtle.forward(rand_distance)
#
# print(window.window_width() / 2)
# window.exitonclick()
#
# # End
