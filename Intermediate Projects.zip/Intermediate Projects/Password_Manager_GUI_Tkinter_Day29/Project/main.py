import random
import tkinter as tk
from tkinter import messagebox
# The reason that we have to import messagebox as a separate module is
# that it is entirely a separate module and we need to import it separately.
import pyperclip

# Pyperclip is a cross-platform Python module for accessing your computer's clipboard functions.
# It allows Python programs to send text to the system clipboard (copy) and retrieve text from it (paste)

PINK = "#e2979c"
RED = "#e7305b"
GREEN = "#9bdeac"
YELLOW = "#f7f5dd"
WHITE = "#FFFFFF"
FONT_NAME = "Cousrier"


# ---------------------------- PASSWORD GENERATOR ------------------------------- #
# The following function is taken from Day 5 password
#  generator project with a few changes here and there.
def generate_password():
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
               'v',
               'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
               'R',
               'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

    nr_letters = random.randint(8, 10)
    nr_symbols = random.randint(2, 4)
    nr_numbers = random.randint(2, 4)

    password_list = []

    password_letters = [random.choice(letters) for i in range(nr_letters)]

    password_symbols = [random.choice(symbols) for i in range(nr_symbols)]

    password_numbers = [random.choice(numbers) for i in range(nr_numbers)]

    password_list = password_letters + password_symbols + password_numbers

    random.shuffle(password_list)

    # password = ""
    # for char in password_list:
    #     password += char

    # The below line is just a short way to create the password
    # string variable thus reducing the above code

    password = "".join(password_list)
    # join() concatenate elements of an iterable (such as a list, tuple, or set)
    # into a single string, with a specified separator placed between each element.
    # Here the specified string is nothing, that is why there is an empty string
    # before the join() method because we want to simply join the elements, and
    # want nothing in between them

    password_label_entry.delete(0, tk.END)
    password_label_entry.insert(0, password)
    pyperclip.copy(password)
    # The above line just simply copies the given argument string to the clipboard of the computer


# ---------------------------- SAVE PASSWORD ------------s------------------- #

def save_info():
    with open("data.txt", "a") as password_file:
        web_name = website_name_entry.get()
        email_or_username = email_or_username_entry.get()
        password = password_label_entry.get()

        if len(web_name) == 0 or len(email_or_username) == 0 or len(password) == 0:
            messagebox.showerror(title="Error", message="You have left some fields empty")
        else:
            confirmation = messagebox.askokcancel(title=web_name,
                                                  message=f"These are the details entered:\n Email: {email_or_username}\n Password: {password}\n is it ok?")
            if confirmation:
                password_file.write(f"Website Name: {web_name} | Email: {email_or_username} | Password: {password}\n")
                website_name_entry.delete(0, tk.END)
                email_or_username_entry.delete(0, tk.END)
                email_or_username_entry.insert(0, "saqlain@gmail.com")
                password_label_entry.delete(0, tk.END)
                website_name_entry.focus()


# ---------------------------- UI SETUP ------------------------------- #


window = tk.Tk()
window.title("Password Manager")
window.config(padx=20, pady=20, bg=WHITE)

logo_image = tk.PhotoImage(file="logo.png")
canvas = tk.Canvas(width=200, height=189, bg=WHITE)
canvas.create_image(100, 95, image=logo_image)
canvas.grid(row=0, column=1)
canvas.config(highlightthickness=0)

website_name_label = tk.Label(text="Website: ")
website_name_label.grid(row=1, column=0)
website_name_label.config(highlightthickness=0, bg=WHITE)

website_name_entry = tk.Entry()
website_name_entry.grid(row=1, column=1, columnspan=2, sticky='nsew', padx=10, pady=5)
website_name_entry.focus()
website_name_entry.config(width=35)
# 'sticky' aligns and stretches the widget to fill the cell

email_or_username_label = tk.Label(text="Email/Username : ")
email_or_username_label.grid(row=2, column=0)
email_or_username_label.config(highlightthickness=0, bg=WHITE)

email_or_username_entry = tk.Entry()
email_or_username_entry.grid(row=2, column=1, columnspan=2, sticky='nsew', padx=10, pady=5)
email_or_username_entry.config(width=35)
email_or_username_entry.insert(tk.END, "saqlain@gmail.com")
# The first argument in the above function is the index
# where we want to insert the string in the entry box.

password_label = tk.Label(text="Password: ")
password_label.grid(row=3, column=0)
password_label.config(highlightthickness=0, bg=WHITE)

password_label_entry = tk.Entry()
password_label_entry.grid(row=3, column=1, sticky='nsew', padx=10, pady=5)
password_label_entry.config(width=21)

generate_password_btn = tk.Button(text="Generate password", command=generate_password)
generate_password_btn.grid(row=3, column=2)
generate_password_btn.config(highlightthickness=0)
generate_password_btn.config(bg=WHITE)

add_btn = tk.Button(text="Add", width=36, command=save_info)
add_btn.grid(row=4, column=1, columnspan=3, sticky='nsew')
add_btn.config(bg=WHITE)

window.mainloop()
