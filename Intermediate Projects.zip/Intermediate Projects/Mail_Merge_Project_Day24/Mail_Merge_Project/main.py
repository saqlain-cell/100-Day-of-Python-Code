# TODO: Create a letter using starting_letter.txt
# for each name in invited_names.txt
# Replace the [name] placeholder with the actual name.
# Save the letters in the folder "ReadyToSend".

# Hint1: This method will help you: https://www.w3schools.com/python/ref_file_readlines.asp
# Hint2: This method will also help you: https://www.w3schools.com/python/ref_string_replace.asp
# Hint3: THis method will help you: https://www.w3schools.com/python/ref_string_strip.asp

# # My Own Coded Project
# PLACEHOLDER = "[name]"
# with open("./Input/Letters/starting_letter.txt") as starting_letter:
#     contents = starting_letter.read()
#
# with open("./Input/Names/invited_names.txt") as invited_persons_file:
#     for line in invited_persons_file:
#         cleaned_line = line.strip("\n")
#         new_letter_content = contents.replace(PLACEHOLDER, cleaned_line)
#
#         with open(f"./Output/ReadyToSend/letter_for_{cleaned_line}.txt", mode="w") as new_letter:
#             new_letter.write(new_letter_content)
# # End


# # Instructor Coded Project
# PLACEHOLDER = "[name]"
#
# with open("./Input/Names/invited_names.txt") as names_file:
#     names = names_file.readlines()
#
# with open("./Input/Letters/starting_letter.txt") as letter_file:
#     letter_contents = letter_file.read()
#     for name in names:
#         stripped_name = name.strip()
#         new_letter = letter_contents.replace(PLACEHOLDER, stripped_name)
#         with open(f"./Output/ReadyToSend/letter_for_{stripped_name}.txt", mode="w") as completed_letter:
#             completed_letter.write(new_letter)
# # End
