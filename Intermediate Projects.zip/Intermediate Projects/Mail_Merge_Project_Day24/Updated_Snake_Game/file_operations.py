# # Task
# # In the following mechanism, we manually need to close the file ourselves.
# # In the next example, we will use "with" where the computer itself closes the file for us without manually needing to close it.
# file = open("C:\\Users\\saqla\\Desktop\\my_file.txt")
# # file = open("C:/Users/saqla/Desktop/my_file.txt"), # instead of the above one we can also use this.
# contents = file.read()
#
# print(contents)
# file.close()  # remember to close the file after opening it.
# # End

# # Task
# # In this example, we will use "with" where the computer will automatically close the file for use after we're finished with it.
# # and we are performing a read operation here.
# with open("C:\\Users\\saqla\\Desktop\\my_file.txt") as file:
#     contents = file.read()
#     print(contents)
# # End


# # Task
# # In this example, we will perform a write operation.
#
# with open("C:\\Users\\saqla\\Desktop\\my_file.txt",
#           mode="w") as file:  # when we don't provide a mode argument, it's default value is "r" which refers to read.
#     file.write("My brother mithu bought a PS2.")
#
# # Here, what will happen is that all the previously written content will be overwritten by this one.
# # meaning all the previous one will be deleted, and this one will be written
#
# # End

# # Task
# # If we want to perform a write operation that does overwrite the previous content, then we use the following method
#
# with open("C:\\Users\\saqla\\Desktop\\my_file.txt",
#           mode="a") as file:  # "a" stands for append here just like lists' append method.
#     file.write("\nand i also bought a PS2.")
#
# # End


# # Task
#
# # Important Note:
# # In both write methods, whether it be "w" or "a", or anything else. If we try to write to a file that does not exist.
# # It will first create the file for us, and then write to the file.
#
# with open("new_file.txt", mode="w") as file:
#     file.write("This is a new file created by Saqlain Farooq.")
#
# # End


# # Task
# # In this task, we demonstrate how to read a file using relative path instead of absolute path which we've been doing so far.
#
# with open(
#         "../../../my_file.txt") as file:  # The detail of this relative path is present on notebook register on page no. 131 and 132.
#     contents = file.read()
#     print(contents)
#
# # or we can use the following
#
# with open(
#         "../../../../Desktop/my_file.txt") as file:  # The detail of this relative path is present on notebook register on page no. 131 and 132.
#     contents = file.read()
#     print(contents)
#
# # End
