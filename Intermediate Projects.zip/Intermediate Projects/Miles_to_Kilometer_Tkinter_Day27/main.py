import tkinter

# # This tkinter module is actually ported from another technology called tk, and
# # tk actually has very different syntax from python. So to make the tk work in python,
# # what they've actually done is that they took commands from tk and converted those commands
# # into optional keyword arguments
# # The example of this is shown in the following Car class
#
# # Task
# # Example for how tk is made into tkinter
#
# class Car:
#     def __init__(self, **kwargs):
#         self.make = kwargs["make"]
#         self.model = kwargs.get("model")
#         self.color = kwargs.get("color")
#         self.seats = kwargs.get("seats")
#         # We can get the value of a key from brackets, but we can also get it by specifying the get() method.
#         # But the benefit of getting the value by the second method is that if the key does not exist,
#         # it gives us the value None
#
#
# my_car = Car(make="Nissan", model="GT-R")
#
# print(my_car.make)
# print(my_car.model)
#
# # So, this is how the tkinter module is created in Python from tk.
# # End

# # Task
#
# window = tkinter.Tk()  # This is equivalent to the screens
# # that we've been creating in python turtle module
# # Tk stands for Tool Kit.
#
# window.title("My First GUI Program.")
# window.minsize(width=500, height=300)
#
# my_label = tkinter.Label(
#     text="I am a Label",
#     font=("Arial", 24,
#           "bold"))
# # This lines creates the label, we need to specify the text keyword argument while creating the label.
# my_label.pack()  # what pack() does is that it puts the label onto the screen and centers this label on the screen.
#
# # my_label.pack(side="left")  # what this does is that makes the label appear on the left side of the screen.
# # We can give it value left, right, bottom
#
# # my_label.pack(expand=True)  # what this does if set to True is that label expands to take the width of the entire screen
#
# # Inner Task
# # How can we change the properties of a tkinter components that we've created
#
# my_label["text"] = "This is Saqlain Farooq's text"  # By this, we can change only one property
# my_label.config(text="Saqlain Farooq's new Text", font=("Arail", 24, "bold"))
#
#
# # By the above line, we can change multiple properties
#
# # Inner Task End
# def button_clicked():
#     my_label["text"] = tkinter_input.get()
#
#
# # In addition to labels, we can also create buttons
# btn_1 = tkinter.Button(text="Click Me", command=button_clicked)
# # The argument "command" in the above line acts as the event listener
# # that calls the function button_clicked whenever the button is clicked.
#
# btn_1.pack()  # This is used to set the button in the center, and display the button
#
# tkinter_input = tkinter.Entry()
# tkinter_input.pack()
# tkinter_input_value = tkinter_input.get()  # This returns the Tkinter's input value as a string
# # but when we run the above line, there is nothing in the input box, because initially
# # it is empty and we get nothing. So we can get the value from the input by an event listener method
#
#
# window.mainloop()
#
# # Explanation of window.mainloop():
# # window.mainloop() starts Tkinter’s event loop.
# #
# # Simple meaning:
# # It tells the program to keep the window open and wait for user actions (like clicks, typing, resizing, etc.). The program keeps running inside this loop until the window is closed.
# #
# # In short:
# # 👉 window.mainloop() keeps the GUI window running and responsive.
#
# # Important Note: For any component of tkinter module whether it be a button,
# # or a label, or input, we have to provide it the function pack() for it to
# # be displayed on the screen.
#
# # End
