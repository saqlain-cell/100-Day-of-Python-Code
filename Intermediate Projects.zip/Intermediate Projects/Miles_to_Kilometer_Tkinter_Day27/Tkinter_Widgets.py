from tkinter import *

# Creating a new window and configurations
window = Tk()
window.title("Widget Examples")
window.minsize(width=500, height=500)

# Labels
label = Label(text="This is old text")
label.config(text="This is new text")
label.pack()


# Buttons
def action():
    print("Do something")


# calls action() when pressed
button = Button(text="Click Me", command=action)
button.pack()

# Entries
entry = Entry(width=30)
# Add some text to begin with
entry.insert(END, string="Some text to begin with.")
# Gets text in entry, This allows the Tkinter module to figure out which component
#  you're referring to. So "End" basically mean the last widget created.
print(entry.get())
entry.pack()

# Text
text = Text(height=5, width=30)
# The "height" argument in the above line basically refers to the number of lines
# Puts cursor in textbox.
text.focus()
# Adds some text to begin with.
text.insert(END, "Example of multi-line text entry.")
# Get's current value in textbox at line 1, character 0
print(text.get("1.0", END))
# The "1.0" which is given as an argument in the above line means
# to start from the first character at the first line in the text.
text.pack()


# Spinbox
def spinbox_used():
    # gets the current value in spinbox.
    print(spinbox.get())


spinbox = Spinbox(from_=0, to=10, width=5, command=spinbox_used)
spinbox.pack()


# Scale
# Called with current scale value.
def scale_used(value):
    print(value)


scale = Scale(from_=0, to=100, command=scale_used)
scale.pack()


# Checkbutton
def checkbutton_used():
    # Prints 1 if On button checked, otherwise 0.
    print(checked_state.get())


# variable to hold on to checked state, 0 is off, 1 is on.
checked_state = IntVar()
# In Tkinter, IntVar() is a special variable that stores an
# integer value and connects it to a widget.
checkbutton = Checkbutton(text="Is On?", variable=checked_state, command=checkbutton_used)
# Now, we have passed the special created variable checked_state to the check_button created widget.
checked_state.get()  # Now, we will get the initial value of the checkbox using this
checkbutton.pack()


# Radiobutton
def radio_used():
    print(radio_state.get())


# Variable to hold on to which radio button value is checked.
radio_state = IntVar()
radiobutton1 = Radiobutton(text="Option1", value=1, variable=radio_state, command=radio_used)
radiobutton2 = Radiobutton(text="Option2", value=2, variable=radio_state, command=radio_used)
radiobutton1.pack()
radiobutton2.pack()


# Listbox
def listbox_used(event):
    # Gets current selection from listbox
    print(listbox.get(listbox.curselection()))


listbox = Listbox(height=4)
fruits = ["Apple", "Pear", "Orange", "Banana"]
for item in fruits:
    listbox.insert(fruits.index(item), item)
# listbox.curselection() → returns the index (position) of the selected item
# listbox.get(index) → returns the text at that index

listbox.bind("<<ListboxSelect>>", listbox_used)
# listbox.bind() connects an event to a function so the function runs when that event happens.
# "<<ListboxSelect>>" → event when the user selects an item in the listbox
# listbox_used → function that runs when that selection happens

listbox.pack()
window.mainloop()
