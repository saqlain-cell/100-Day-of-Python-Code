# # Task 1
#
# # In this Task, we will demonstrate as to how to give the layout
# # and positioning of your GUI Tkinter Module in python.
# # Tkinter has different kinds of layout managers to position
# # each of the widgets in your GUI program, but three important ones
# # that you should know about are (1)Pack (2)Place (3)Grid.
#
# # (1) Pack:
# # Pack stacks widgets on top of each other by default. It is used for
# # quick, straightforward layouts where widgets are arranged relative to
# # one another.
# # But as we have previously seen that you change the as to where the
# # contents are placed according to place() by using pack(side= "left")
# # or any other kind of argument, but you need to use one characteristic
# # for all the widgets for the specified property(side="left") in tkinter
# # widget for it to be noticeable.
# # Drawback:
# # It is very very complicated to use place() for precise positioning
# # in your GUI Program. That's why there is not a single layout manager, but many
#
# # Using pack(side = "left") is detailed in the following example
#
# from tkinter import *
#
#
# def button_clicked():
#     print("I got clicked")
#     new_text = input.get()
#     my_label.config(text=new_text)
#
#
# window = Tk()
# window.title("My First GUI Program")
# window.minsize(width=500, height=300)
#
# # Label
# my_label = Label(text="I Am a Label", font=("Arial", 24, "bold"))
# my_label.config(text="New Text")
# my_label.place()
#
# # Button
# button = Button(text="Click Me", command=button_clicked)
# button.place()
#
# # Entry
# input_entry = Entry(width=10)
# print(input_entry.get())
# input_entry.place()
#
# window.mainloop()
# # End


# # Task 2
# # This task goes into explaining place()
# # place() is all precise positioning
# # When you use place(), you can give x and y
# # coordinate value in the Tkinter module.
#
# # Important Note:
# # If you create a widget in the Tkinter module and you have no layout manager specified
# # for a particular widger, then that particular widget won't show in the GUI.
#
# # Drawback:
# # The drawback of place() is that we need precise coordinates to place
# # each widget in the GUI because it works well for 2 or 3 items, but it
# # quickly becomes a nightmare for 50 or more items.
#
# from tkinter import *
#
#
# def button_clicked():
#     print("I got clicked")
#     new_text = input.get()
#     my_label.config(text=new_text)
#
#
# window = Tk()
# window.title("My First GUI Program")
# window.minsize(width=500, height=300)
#
# # Label
# my_label = Label(text="I Am a Label", font=("Arial", 24, "bold"))
# my_label.config(text="New Text")
# my_label.place(x=100, y=0)
#
# # Button
# button = Button(text="Click Me", command=button_clicked)
# button.place(x=0, y=0)
#
# # Entry
# input_entry = Entry(width=10)
# print(input_entry.get())
# input_entry.place(x=0, y=0)
#
# window.mainloop()
#
# # End


# # Task 3
# # This task explains the grid layout manager of Tkinter module
# # The grid() layout manager in Tkinter is a geometry manager that organizes
# # widgets in a 2-dimensional table-like structure using rows and columns
#
# # The Grid is one of the easiest layout managers to implement
#
# # Important Note: You cannot mix Grid and Pack in the same program.
# # For example, if you use pack() layout manager for label
# # and button, but then use grid layout manager for entry,
# # then you will get an error
# # In Short: Grid and Pack are incompatible with one another in the
# # same layout manager.
#
# # Important Note:
# # Tkinter grid starts building layout from row 0 and column 0, so
# # placing a widget directly at row 6, column 6 without placing
# # other widgets before it can cause unexpected placement.
# # In short, for row and column, you can place a widget in the
# # next most row and column from the last filled row and column
# # not the ones after, e.g., lets say a widget is placed at the
# # 2nd row and 3rd column, you can place another widget in rows
# # 1, 2 and 3, and not in any other rows. Same is the case for column
# # you can place the widget in column 1,2,3,4 and not in any other column
#
#
# from tkinter import *
#
#
# def button_clicked():
#     print("I got clicked")
#     new_text = input.get()
#
#
# window = Tk()
# window.title("My First GUI Program")
# window.minsize(width=500, height=300)
#
# # Label
# my_label = Label(text="I Am a Label", font=("Arial", 24, "bold"))
# my_label.config(text="New Text")
# my_label.grid(row=0, column=0)
#
# # Button
# old_button = Button(text="Old Button", command=button_clicked)
# old_button.grid(row=1, column=1)
#
# # New Button
# new_button = Button(text="New Button", command=button_clicked)
# new_button.grid(row=0, column=2)
#
# # Entry
# input_entry = Entry(width=10)
# print(input_entry.get())
# input_entry.grid(row=2, column=3)
#
# window.mainloop()
#
# # End


# # Task 4
# # This Task explains as to how to add padding in your widgets
# # Padding in Tkinter refers to the extra space added around or inside a widget to improve the visual
# # layout and readability of a graphical user interface (GUI).
#
# from tkinter import *
#
#
# def button_clicked():
#     print("I got clicked")
#     new_text = input.get()
#
#
# window = Tk()
# window.title("My First GUI Program")
# window.minsize(width=500, height=300)
# window.config(padx=20, pady=20)
#
# # Label
# my_label = Label(text="I Am a Label", font=("Arial", 24, "bold"))
# my_label.config(text="New Text")
# my_label.grid(row=0, column=0)
# my_label.config(padx=10, pady=10)
#
# # Button
# old_button = Button(text="Old Button", command=button_clicked)
# old_button.grid(row=1, column=1)
# old_button.config(padx=10, pady=10)
#
# # New Button
# new_button = Button(text="New Button", command=button_clicked)
# new_button.grid(row=0, column=2)
# new_button.config(padx=10, pady=10)
#
# # Entry
# input_entry = Entry(width=10)
# print(input_entry.get())
# input_entry.grid(row=2, column=3, padx=10, pady=10)
#
# window.mainloop()
#
# # End
