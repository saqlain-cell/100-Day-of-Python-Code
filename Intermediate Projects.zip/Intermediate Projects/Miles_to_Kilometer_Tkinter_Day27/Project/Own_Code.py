# # My own code project is same as instructor coded project.
#
# import tkinter as tk
#
# FONT = ("Arial", 12)
#
#
# def miles_to_km():
#     miles = float(miles_input.get())
#     km = round(miles * 1.60934)
#     km_value_label["text"] = str(km)
#
#
# window = tk.Tk()
# window.title("Mile to Km Converter")
# window.minsize(width=200, height=125)
# window.config(padx=20, pady=20)
#
# miles_input = tk.Entry(width=7)
# miles_input.grid(row=0, column=1, padx=5, pady=5)
#
# miles_label = tk.Label(text="Miles", font=FONT)
# miles_label.grid(row=0, column=2)
#
# equal_to_label = tk.Label(text="is equal to", font=FONT)
# equal_to_label.grid(row=1, column=0)
#
# km_value_label = tk.Label(text="   0   ", font=FONT)
# km_value_label.grid(row=1, column=1)
#
# km_label = tk.Label(text="Km", font=FONT)
# km_label.grid(row=1, column=2)
#
# calculate_btn = tk.Button(text="Click Me", command=miles_to_km)
# calculate_btn.config(padx=5, pady=5)
# calculate_btn.grid(row=3, column=1)
#
# window.mainloop()
