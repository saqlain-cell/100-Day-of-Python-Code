# # Task
# # This task shows as to how to provide unlimited arguments to a function
# # also as unlimited arguments or unlimited positional arguments
# def add(*args):  # the argument datatype given will be in the form of a tuple
#     total = 0
#     print(args[0])  # As the given argument datatype is a tuple, we can also access the datatype by giving index
#     for n in args:
#         total += n
#
#     return total
#
#
# print(add(2, 3, 4, 5, 6, 8))
#
# # End


# # Task
# # The following shows as to how is **kwargs is implemented and carried out.
# def calculate(n, **kwargs):
#     # print(kwargs)
#     # # or
#     # print(type(kwargs))
#     n += kwargs["add"]
#     n *= kwargs["multiply"]
#     print(n)
#
#
# calculate(2, add=3, multiply=3)
# # End
