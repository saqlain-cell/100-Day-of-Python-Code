# # My own code Coffee  project
# MENU = {
#     "espresso": {
#         "ingredients": {
#             "water": 50,
#             "coffee": 18,
#         },
#         "cost": 1.5,
#     },
#     "latte": {
#         "ingredients": {
#             "water": 200,
#             "milk": 150,
#             "coffee": 24,
#         },
#         "cost": 2.5,
#     },
#     "cappuccino": {
#         "ingredients": {
#             "water": 250,
#             "milk": 100,
#             "coffee": 24,
#         },
#         "cost": 3.0,
#     },
# }

# resources = {
#     "water": 300,
#     "milk": 200,
#     "coffee": 100,
# }

# profit = 0

# # TODO NO. 1 Print Report of all coffeee machine resources


# def print_report():
#     for resource in resources:
#         print(f"{resource.title()}: {resources[resource]}")
#     print(f"Money: {profit}")


# def get_coffee_type_ingredients(coffee_type):
#     return MENU[coffee_type]["ingredients"]


# def get_coffee_type_cost(coffee_type):
#     return MENU[coffee_type]["cost"]


# def sufficient_resources(coffee_type):
#     coffee_type_ingredients = get_coffee_type_ingredients(coffee_type)

#     for ingredient in coffee_type_ingredients:
#         coffee_type_current_ingredient_requirement = coffee_type_ingredients[ingredient]
#         current_ingredient_amount_available = resources[ingredient]

#         if (
#             current_ingredient_amount_available
#             < coffee_type_current_ingredient_requirement
#         ):
#             print(f"Sorry, there is not enough {ingredient}.")
#             return False

#     return True


# def process_coins(coffee_type):
#     print("Please insert coins.")
#     quarters = int(input("How many quarters? "))
#     dimes = int(input("How many dimes? "))
#     nickels = int(input("How many nickels? "))
#     pennies = int(input("How many pennies? "))

#     amount_given_by_customer = (
#         (quarters * 0.25) + (dimes * 0.10) + (nickels * 0.05) + (pennies * 0.01)
#     )

#     return amount_given_by_customer


# def deduct_resources(coffee_type):
#     coffee_type_ingredients = get_coffee_type_ingredients(coffee_type)

#     for ingredient in coffee_type_ingredients:
#         resources[ingredient] = (
#             resources[ingredient] - coffee_type_ingredients[ingredient]
#         )


# def make_coffee(coffee_type):
#     has_resources = sufficient_resources(coffee_type)

#     if has_resources:

#         amount_given_by_customer = process_coins(coffee_type)

#         coffee_type_cost = get_coffee_type_cost(coffee_type)

#         if amount_given_by_customer < coffee_type_cost:
#             print("Sorry that's not enough money. Money refunded.")
#         else:
#             change = amount_given_by_customer - coffee_type_cost
#             print(f"Here is ${change} in change.")
#             print(f"Here  is your {coffee_type}. Enjoy!")
#             deduct_resources(coffee_type)
#             global profit
#             profit += coffee_type_cost


# is_on = True

# while is_on:
#     choice = input("What would you like? (espresso/latte/cappuccino): ").lower()

#     if choice == "off":
#         is_on = False
#     elif choice == "report":
#         print_report()
#     else:
#         make_coffee(choice)
# # End


# # Instructor code project

# MENU = {
#     "espresso": {
#         "ingredients": {
#             "water": 50,
#             "coffee": 18,
#         },
#         "cost": 1.5,
#     },
#     "latte": {
#         "ingredients": {
#             "water": 200,
#             "milk": 150,
#             "coffee": 24,
#         },
#         "cost": 2.5,
#     },
#     "cappuccino": {
#         "ingredients": {
#             "water": 250,
#             "milk": 100,
#             "coffee": 24,
#         },
#         "cost": 3.0,
#     },
# }

# profit = 0
# resources = {
#     "water": 300,
#     "milk": 200,
#     "coffee": 100,
# }


# def is_resource_sufficient(order_ingredients):
#     """Returns True when order can be made, False if ingredients are insufficient."""
#     for item in order_ingredients:
#         if order_ingredients[item] > resources[item]:
#             print(f"Sorry there is not enough {item}.")
#             return False
#     return True


# def process_coins():
#     """Returns the total calculated from coins inserted."""
#     print("Please insert coins.")
#     total = int(input("how many quarters?: ")) * 0.25
#     total += int(input("how many dimes?: ")) * 0.1
#     total += int(input("how many nickles?: ")) * 0.05
#     total += int(input("how many pennies?: ")) * 0.01
#     return total


# def is_transaction_successful(money_received, drink_cost):
#     """Return True when the payment is accepted, or False if money is insufficient."""
#     if money_received >= drink_cost:
#         change = round(money_received - drink_cost, 2)
#         print(f"Here is ${change} in change.")
#         global profit
#         profit += drink_cost
#         return True
#     else:
#         print("Sorry that's not enough money. Money refunded.")
#         return False


# def make_coffee(drink_name, order_ingredients):
#     """Deduct the required ingredients from the resources."""
#     for item in order_ingredients:
#         resources[item] -= order_ingredients[item]
#     print(f"Here is your {drink_name} ☕️. Enjoy!")


# is_on = True

# while is_on:
#     choice = input("What would you like? (espresso/latte/cappuccino): ")
#     if choice == "off":
#         is_on = False
#     elif choice == "report":
#         print(f"Water: {resources['water']}ml")
#         print(f"Milk: {resources['milk']}ml")
#         print(f"Coffee: {resources['coffee']}g")
#         print(f"Money: ${profit}")
#     else:
#         drink = MENU[choice]
#         if is_resource_sufficient(drink["ingredients"]):
#             payment = process_coins()
#             if is_transaction_successful(payment, drink["cost"]):
#                 make_coffee(choice, drink["ingredients"])


# # End
