import tkinter as tk
import time

# Important Note:
# Tkinter is not well documented

# Canvas Widget:
# The Tkinter Canvas widget provides a rectangular area within
# a Python GUI where you can draw various graphical
# items and even place other widgets.

# A canvas in Tkinter is ver much similar to a real-life like canvas.
# We can draw shapes on the canvas on top of on another.

# ---------------------------- CONSTANTS ------------------------------- #
PINK = "#e2979c"
RED = "#e7305b"
GREEN = "#9bdeac"
YELLOW = "#f7f5dd"
FONT_NAME = "Cousrier"
WORK_MIN = 25
SHORT_BREAK_MIN = 5
LONG_BREAK_MIN = 20
text = "✅"
reps = 0
timer = None


# ---------------------------- TIMER RESET ------------------------------- #
def reset_timer():
    window.after_cancel(timer)
    # window.after_cancel() in Python (Tkinter) is used to stop a scheduled function from running.
    # Think of it as a "cancel" button for a timer created by window.after().
    # But important note, we need to create a variable for the thing that we want to cancel,
    # and pass that variable to the after_cancel() function
    title_label.config(text="Timer", fg=GREEN)
    canvas.itemconfig(timer_text, text=f"00:00")
    check_mark_label.config(text="")
    global reps
    reps = 0


# ---------------------------- TIMER MECHANISM ------------------------------- #
def start_timer():
    global reps
    work_sec = WORK_MIN * 60
    short_break_sec = SHORT_BREAK_MIN * 60
    long_break_sec = LONG_BREAK_MIN * 60

    reps += 1

    if reps % 8 == 0:
        count_down(long_break_sec)
        title_label.config(text="Long Break", fg=RED)
    elif reps % 2 == 0:
        count_down(short_break_sec)
        title_label.config(text="Short Break", fg=PINK)
    else:
        count_down(work_sec)
        title_label.config(text="Work", fg=GREEN)


# ---------------------------- COUNTDOWN MECHANISM ------------------------------- #

def count_down(count):
    minutes = count // 60
    seconds = count % 60
    if 0 <= seconds <= 9:
        seconds = f"0{seconds}"
    canvas.itemconfig(timer_text, text=f"{minutes}:{seconds}")
    # we need to create the timer_text variable, it is a must.
    # The way to change a canvas widget text property is different from label
    # text propery.
    if count > 0:
        global timer
        timer = window.after(1000, count_down, count - 1)
        # We made this variable global so that it can be passed to the
        # reset_timer() function as well.
    else:
        if reps % 2 == 1:
            current_text = check_mark_label.cget("text")
            # The above line is used to get the text property from the label
            check_mark_label.config(text=current_text + "✅")
        start_timer()

        # ------------------- NOTES -------------------
        # window.after(ms, func) schedules func for later; it does NOT block execution of other functions.
        # start_timer() calls count_down() which schedules next call and returns.
        # Therefore, lines after start_timer() execute immediately(while GUI stays responsive) if any are present,
        #  but in our code they are not


# ---------------------------- UI SETUP ------------------------------- #

# The following function exists as an example to explain you to what
# window.after() function does in python

# def say_something(a, b, c):
#     print(a)
#     print(b)
#     print(c)


window = tk.Tk()
window.title("Pomodora")
window.config(padx=100, pady=50, bg=YELLOW)
# What we have done is that we have created a canvas equal to the size
# of the image, then we have simply given padding around the image.

# # The following line is an example to explain to you the window.after() function
# window.after(3000, say_something, 5, 6, 7)
# # The above line is an example to explain the after() function.
# # The arguments starting from the third argument in the above line
# # are the arguments that we are passing to the say_something function.

title_label = tk.Label(text="Timer", font=(FONT_NAME, 50), fg=GREEN, bg=YELLOW)
title_label.grid(row=0, column=1)

canvas = tk.Canvas(width=200, height=224, bg=YELLOW, highlightthickness=0)
# We created a canvas with size 200X223 because
# these are the dimension of the tomato picture
# Question - What does highlightthickness argument do in the above method
# Answer - This removes the border highlight around the Canvas.
tomato_img = tk.PhotoImage(file="tomato.png")
# We cannot simply pass the argument "tomato.png" to the create_image present below
# method as an argument. What we need to is that we need to create a
# variable like the above one(tomato_img) where we need to give it the
# class PhotoImage() with file argument containing the value of the image.
# tk.PhotoImage(file="tomato.png") loads an image file so it can be used
# in a Tkinter widget (like a Label, Button, or Canvas).
canvas.create_image(100, 112, image=tomato_img)
# In the above image, we are giving the x and y coordinates for the
# image to be placed in the canvas, next we are providing the image as
# file to be placed in the canvas. Since the canvas is equal to the size
# of the image, so we have placed the image in the middle of the canvas.
timer_text = canvas.create_text(103, 130, text="00:00", fill="white", font=(FONT_NAME, 35, "bold"))
# fill here means the colour of the text
# Just like the method create_image() works, the method create_text() works
# in the same way, first we need to specify it's x and y values in the canvas.
# Then we need to specify the text that we need to place in the canvas.
canvas.grid(row=1, column=1)
# At last, we don't need to forget the layout manager that we need to
# specify for the canvas in order for it to be displayed.

btn_start = tk.Button(text="Start", font=(FONT_NAME, 8, "bold"), highlightthickness=0, command=start_timer)
btn_start.grid(row=2, column=0)

btn_reset = tk.Button(text="Reset", font=(FONT_NAME, 8, "bold"), highlightthickness=0, command=reset_timer)
btn_reset.grid(row=2, column=2)

check_mark_label = tk.Label(bg=YELLOW)
check_mark_label.grid(row=3, column=1, pady=20)

window.mainloop()

# The way window.mainloop() works is as the following

# while True:
#     # The code inside here for the GUI program runs in here

# What happens is that whenever this loop runs, the GUI program window screen refreshes,
# and whenever it refreshes, it detects for event driven actions, like if a user pressed
# a button, or did anything, and then updates the screen accordingly. So if we create
# a loop before this loop that runs infinitely, then what will happen is that execution
# will never this loop, and as a result the GUI program window will not show.
# The solution for this problem is window.after() function which is specified above
# somewhere in line no. 39. What does after() do? after always executes the specified
# function after the specified time.

# Check Mark Symbol
# ✅
# End
