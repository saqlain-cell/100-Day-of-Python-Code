# Task
# Example of try - except is as follows
# The elements that are related with exceptions in python are as follows
#
# try:
# Something that might cause an exception
# catch:
# if an exception occurs, the code in here gets executed
# else:
# If no exception occurs, the code in here gets executed
# finally:
# The code in here gets executed whether or not an exception occurs.
# End

# # Task
#
# try:
#     with open("data.txt", "r") as file:
#         file.readlines()
# except FileNotFoundError:
#     print("The file does not exist")
# else:
#     print("The file does exist")
# finally:
#     print("I love python")
#
# # End


# # Task
# # We can have multiple exceptions with the same try block.
# # but only one exception block will run, the reason is
# # below.
#
# try:
#     with open("data.txt", "r") as file:
#         file.read()
#     # what happens is that as soon as the file is not found by the computer,
#     # it jumps straight to its corresponding exception, and the lines below
#     # in the try section do not run as well as their corresponding exception
#     # blocks
#     a_dictionary = {"a_key": "a_value"}
#     print(a_dictionary["asdds"])
# except FileNotFoundError:
#     print("Sorry, the file does not exist.")
# # The difference between the above exception and the below exception
# # is that the below exception is caught as an object, and we can access
# # the attributes and variables of the object exception which is really handy.
# except KeyError as error_message:
#     print(f"The key {error_message} does not exist.")
#
# # End


# # Task
#
# # First, it will create the file from except block in the
# # first execution, then it will read the file on the
# # second execution
# try:
#     file = open("data.txt")
# except FileNotFoundError:
#     file = open("data.txt", "a")
#     # along with opening the file, we need to specify
#     # the operation being performed on it.
#     file.write("Something")
# else:
#     contents = file.read()
#     print(contents)
# finally:
#     file.close()
#     print("The file was closed")
# # End


# # Task
# # Raising Your own Exceptions in this task by using raise keyword.
#
# # Detailed usage of raise keyword is in the next task.
#
# # We can use raise keyword even outside a try catch block
# # but it is recommended to use it inside a try catch block.
#
# raise FileNotFoundError  # without a message
# # or
#
# raise FileNotFoundError("There is no such File")
#
# Notice that when we generate errors using raise, they
# appear in red colored font just like real exception errors.
# # End


# # Task
#
# try:
#     file = open("a_file.txt")
# except FileNotFoundError:
#     file = open("a_file.txt", "a")
# finally:
#     file.close()
#     raise FileNotFoundError("The file does not exist")
# # End


# # Task
# # The following task correctly explains as to how to generate your
# # own exceptions using raise keyword in python.
#
# height = float(input("Height: "))
# weight = int(input("Weight: "))
#
# # 3 meters correspond to 9 foot tall
#
# if height > 3:
#     raise ValueError("Human Height should not be greater than 3 meters.")
#
# bmi = weight / (height ** 2)
# print(bmi)
# # End


# # Task
# # The following is a coding exercise taken from Angela Yu's course.
#
# # What is happening in the following code is that if an exception
# # index out of range occurs, then default output is printed to the
# # console which is "Fruit pie".
#
# fruits = ["Apple", "Pear", "Orange"]
#
#
# def make_pie(index):
#     try:
#         fruit = fruits[index]
#         print(fruit + " pie")
#     except IndexError:
#         print("Fruit pie")
#
#
# make_pie(4)
#
# # End


# # Task
# # This is also a coding exercise taken from Angela Yu's course,
# # this code also very beautifully explains as to how pass can
# # be and is used from the exception KeyError.
#
# # What we have done is that whatever post does not have "like" key
# # present in it, we simply skip it.
#
# facebook_posts = [
#     {'Likes': 21, 'Comments': 2},
#     {'Likes': 13, 'Comments': 2, 'Shares': 1},
#     {'Likes': 33, 'Comments': 8, 'Shares': 3},
#     {'Comments': 4, 'Shares': 2},
#     {'Comments': 1, 'Shares': 1},
#     {'Likes': 19, 'Comments': 3}
# ]
#
#
# def count_likes(posts):
#     total_likes = 0
#     for post in posts:
#         try:
#             total_likes = total_likes + post['Likes']
#         except KeyError:
#             pass
#
#     return total_likes
#
#
# count_likes(facebook_posts)
#
# # End
