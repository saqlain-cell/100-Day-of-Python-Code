# Yai mera code hai
import turtle
from turtle import Screen, Turtle
from snake import Snake
from food import Food
from scoreboard import Scoreboard
import time

# Important Point: When we create a turtle segment on the screen, it is 20X20 pixels

window = Screen()
window.setup(width=600, height=600)
window.bgcolor("black")
window.title("Our Snake Game")
window.tracer(0)
snake = Snake()
food = Food()
scoreboard = Scoreboard(window)
window.update()

window.onkey(snake.up, "Up")
window.onkey(snake.down, "Down")
window.onkey(snake.left, "Left")
window.onkey(snake.right, "Right")
window.listen()

is_game_on = True


def game_over():
    global is_game_on
    scoreboard.game_over()
    is_game_on = False


while is_game_on:
    time.sleep(0.1)  # time.sleep() stops the execution of the current thread, not necessarily
    # the entire program. In a single-threaded program, however, it effectively pauses
    # the entire application because  there is only one thread of execution.
    snake.move()
    window.update()

    if snake.head.distance(food) < 15:
        food.refresh()
        scoreboard.increase_score()
        snake.extend()

    if snake.head.xcor() >= 280 or snake.head.xcor() <= -280 or snake.head.ycor() >= 280 or snake.head.ycor() <= -280:
        game_over()

    for segment in snake.segments[1:]:
        # slicing mechanism has been done in the for in loop
        # which is [1:], what this effectively does is that
        # it excludes the first element from the list while
        # keeping all others for specified operations.
        # We have done this because we don't want to compare
        # head to itself, we want to compare its distance with
        # the rest of the segments, but not with itself, because
        # the game would immediately end when started
        if snake.head.distance(segment) < 10:
            game_over()

window.exitonclick()
