from turtle import Turtle

NORMAL_ALIGNMENT = "right"
GAME_OVER_ALIGNMENT = "center"
NORMAL_FONT = ("Courier", 14, "normal")
GAME_OVER_FONT = ("Courier", 25, "bold")


class Scoreboard(Turtle):
    def __init__(self, window):
        super().__init__()
        self.penup()
        self.score = 0
        self.color("red")
        self.hideturtle()
        self.goto((window.window_width() / 2) - 15, (window.window_height() / 2) - 24)
        self.update_scoreboard()

    def update_scoreboard(self):
        self.write(f"Score: {self.score}", False, NORMAL_ALIGNMENT, NORMAL_FONT)

    def game_over(self):
        self.clear()
        self.goto(0, 0)
        self.write(f"GAME OVER, Final Score: {self.score}", False, GAME_OVER_ALIGNMENT, GAME_OVER_FONT)

    def increase_score(self):
        self.score += 1
        self.clear()
        self.update_scoreboard()
