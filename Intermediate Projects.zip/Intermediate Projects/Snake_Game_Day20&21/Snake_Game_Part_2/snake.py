import turtle

STARTING_POSITIONS = ((0, 0), (-20, 0), (-40, 0))
MOVE_DISTANCE = 20

RIGHT = 0
UP = 90
LEFT = 180
DOWN = 270


class Snake:
    def __init__(self):  # FIXED
        self.segments = []
        self.create_snake()
        self.head = self.segments[0]

    def create_snake(self):
        for position in STARTING_POSITIONS:
            self.add_segment(position)

    def add_segment(self, position):
        new_segment = turtle.Turtle("square")
        new_segment.color("white")
        new_segment.penup()
        new_segment.goto(position)
        self.segments.append(new_segment)

    def extend(self):
        self.add_segment(self.segments[-1].position())

    def move(self):
        # In this function, we start the movement of the snake from the tail segment
        # What is happening is that tail segment moves to the position of the segment
        # present after it, meaning the second last segment. This will happen until
        # the second segment of the snake moves to the position of the head. We cannot
        # move the head in the loop because there is no segment present after the head.
        for seg_num in range(len(self.segments) - 1, 0, -1):
            position_to_move_to = self.segments[seg_num - 1].position()

            # This returns the position of the segment as a tuple where first element
            # of the tuple corresponds to x-axis, and second element corresponds to y-axis
            self.segments[seg_num].goto(position_to_move_to)
            # in the function goto(), we can pass arguments either as two separate number variables, or in the form
            # of a tuple which has two number entries, both are valid.

        self.head.forward(MOVE_DISTANCE)
        # As we also need to move the head, so we moved the
        # head forward a distance equal to its dimensions.

    def up(self):
        if self.head.heading() != DOWN and self.head.heading() != UP:
            self.head.setheading(UP)

    def down(self):
        if self.head.heading() != DOWN and self.head.heading() != UP:
            self.head.setheading(DOWN)

    def left(self):
        if self.head.heading() != LEFT and self.head.heading() != RIGHT:
            self.head.setheading(LEFT)

    def right(self):
        if self.head.heading() != LEFT and self.head.heading() != RIGHT:
            self.head.setheading(RIGHT)
