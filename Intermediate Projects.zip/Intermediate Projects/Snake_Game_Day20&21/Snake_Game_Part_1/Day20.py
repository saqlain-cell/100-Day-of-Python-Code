# Task, My own code
# This is just a side task that i have created and done myself.
# The purpose of this task is to move the snake when the key
# is pressed and keep moving as long as the key is pressed

import turtle

window = turtle.Screen()
window.colormode(255)


def create_snake_base_body():
    snake_base_body = []
    for i in range(3):
        snake_element = turtle.Turtle()
        snake_element.shape("circle")
        snake_element.color(30, 30, 30)
        snake_element.penup()
        snake_base_body.append(snake_element)

    increment_value = 15
    prev_increment = -increment_value
    for snake_element in reversed(
            snake_base_body):  # important for in loop, this make for in loop to start from end of the list and it iterates towards the beginning of the list
        current_increment = prev_increment + increment_value
        snake_element.forward(current_increment)
        prev_increment = current_increment

    return snake_base_body


snake_body = create_snake_base_body()

to_move = False


def move_snake():
    if to_move:
        snake_head = snake_body[0]
        if snake_head.heading() != 90:
            snake_head.setheading(90)

        for i in range(len(snake_body) - 1, 0, -1):
            snake_body[i].goto(snake_body[i - 1].position())

        snake_head.forward(15)

    window.tracer(0)
    window.update()
    window.tracer(1)
    window.ontimer(move_snake, 15)


def stop_snake_north():
    global to_move
    to_move = False


def move_snake_north():
    global to_move
    to_move = True


window.onkeypress(move_snake_north, "Up")
window.onkeyrelease(stop_snake_north, "Up")
move_snake()
window.listen()
window.exitonclick()

# End


# Project


# End
