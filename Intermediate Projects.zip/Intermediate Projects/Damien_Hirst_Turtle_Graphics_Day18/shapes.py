import random


def set_screen(window, shape, width_coordinates, height_coordinates):
    window.tracer(0)
    shape.penup()
    shape.goto(width_coordinates, height_coordinates)
    shape.pendown()
    window.tracer(1)


def draw_damien_hirst(window, shape, start_x, start_y, colors):
    shape.penup()
    for i in range(0, 10):
        shape.speed(1)
        for j in range(0, 10):
            window.tracer(0)
            shape.begin_fill()
            shape.dot(20, random.choice(colors))
            shape.end_fill()
            window.tracer(1)
            shape.forward(50)

        shape.speed(12)
        shape.goto(start_x, shape.ycor() - 50)

    shape.pendown()
