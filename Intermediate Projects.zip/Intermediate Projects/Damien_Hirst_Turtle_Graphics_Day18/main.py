import turtle
from turtle import Turtle, Screen  # The import

# # Task
# timmy_the_turtle = Turtle()
# timmy_the_turtle.shape("turtle")
# timmy_the_turtle.color("red")
#
# window = Screen()
# window.exitonclick()
# # End

# # Task, Difference between the imports
#
# # Task 1:
# import turtle
# This import is most recommended
# timmy_1 = turtle.Turtle()  # need to use prefix turtle. but if we don't use it, it will not give an error in PyCharm, but it will give an error in other editors
# timmy_1.shape("turtle")
# print(timmy_1)
# # End
#
# # Task 2, This kind of import is not recommended
# from turtle import *
#
# timmy = Turtle()  # don't need to use prefix "turtle"
# print(timmy)
# # End
#
# # Task 3:
# from turtle import Turtle
#
# timmy = Turtle()  # don't need to use prefix "turtle"
# print(turtle)
# # End
#
# window = Screen()
# window.exitonclick()
# # Task 4
# from random import *
#
# print(choice([2, 3, 5, 7, 9, 10,
#               14]))  # see no need to use random. prefix before calling the function choice which is a function of the random module
# # End
#
# # End

# # Task
# import heroes  # We have first installed this package globally
#
# print(heroes.gen())
#
# # End

# # Task
# import heroes as h  # This will assign the package a name
#
# print(h.gen())
#
# # End

# # Task
# turtle = Turtle()
# window = Screen()
# window.tracer(0)
# turtle.penup()
# turtle.setposition(-(window.window_width() / 2) + 10, window.window_height() / 2 - 20)
# turtle.pendown()
# window.tracer(1)
# for i in range(25):
#     turtle.forward(10)
#     turtle.penup()
#     turtle.forward(10)
#     turtle.pendown()
#
# window.exitonclick()
# # End

# # Task
# # The goal of this task is to create a triangle, square, pentagon, hexagon, heptagon, octagon, nonagon, decagon
# import turtle as t
# import random
#
# window = Screen()
# tim = t.Turtle()
# colors = [
#     "navy",
#     "crimson",
#     "darkgreen",
#     "purple",
#     "darkorange",
#     "teal",
#     "magenta",
#     "brown"
# ]
#
#
# def draw_shape(num_sides):
#     angle = 360 / num_sides
#     for _ in range(num_sides):
#         tim.forward(100)
#         tim.right(angle)
#
#
# for shape_side_n in range(3, 10):
#     tim.color(random.choice(colors))
#     draw_shape(shape_side_n)
# window.exitonclick()
# # End


# # Task
# import turtle as t
# import random
# import colorgram
#
# window = Screen()
# turtle = t.Turtle()
# t.colormode(255)
#
#
# def extract_colours_from_image(image_url):
#     colours = colorgram.extract(image_url, 100)
#     # We have chosen 100 as the number of colours here, because it is the
#     # maximum amount a painting or a picture can have distinct colours
#
#     colours_list = list()
#     for colour in colours:
#         colour = colour.rgb
#         colour = tuple(
#             colour)  # colour was already a tuple-like object, but for assurity, we have converted it to a tuple
#         colours_list.append(colour)
#
#     return colours_list
#
#
# def random_walk():
#     directions = [0, 90, 180, 270]
#     turtle.pensize(5)
#     turtle.speed("fastest")
#     for i in range(200):
#         turtle.color(random.choice(colors))
#         fd = random.randint(20, 30)
#         direction = random.choice(directions)
#         window.tracer(0)
#         turtle.setheading(direction)
#         window.tracer(1)
#         turtle.forward(fd)
#     turtle.speed(6)  # This is the normal speed of the turtle
#
#
# def spirograph(size_of_gap):
#     turtle.speed("fastest")
#     for i in range(int(360 / size_of_gap)):
#         turtle.color(random.choice(colors))
#         turtle.circle(100)
#         turtle.setheading(turtle.heading() + size_of_gap)
#
#
# colors = extract_colours_from_image("damien_hirst_spot_painting.webp")
#
# spirograph(5)
# window.exitonclick()
# # End


# # Task, most important, crux of the project
# # How to extract colors from images, for this, we will use library colorgram.py which we
# import turtle
# import colorgram
#
# timmy_the_turtle = Turtle()
# window = Screen()
# window.colormode(255)
#
# # colorgram.extract() returns a list of Color objects.
# # Each Color object represents one detected color in the image.
# # Each object contains attributes like .rgb, .hsl, and .proportion
# # that store the color values and how much of the image the color occupies.
# # the attributes rgb, and hsl are object themselves which behave like tuples
# # not exactly tuples, but tuple-like object, so we can pass these object to a function
# # which requires a tuple.
#
#
# colors = colorgram.extract("damien_hirst_spot_painting.webp", 100)
#
# first_color = colors[5]  # the reaseon we have chosen colors[5] here becuase it is brown, and visible on the screen
# first_color = first_color.rgb
# first_color = tuple(first_color)
#
# timmy_the_turtle.dot(100, first_color)
#
# window.exitonclick()
# # End

# # Project, My Own Code
#
# from turtle import *
# from shapes import *
# import colorgram
#
#
# def extract_colours_from_image(image_url):
#     colours = colorgram.extract(image_url, 100)
#     # We have chosen 100 as the number of colours here, because it is the
#     # maximum amount a painting or a picture can have distinct colours
#
#     colours_list = list()
#     for colour in colours:
#         colour = colour.rgb
#         colour = tuple(
#             colour)  # colour was already a tuple-like object, but for assurity, we have converted it to a tuple
#         colours_list.append(colour)
#
#     return colours_list
#
#
# turtle = Turtle()
# window = Screen()
# window_height = Screen().window_height()
# window_width = Screen().window_width()
# window.colormode(255)
#
# colors = extract_colours_from_image("damien_hirst_spot_painting.webp")
# start_x = -(window_width / 2) + 50
# start_y = (window.window_height() / 2) - 50
#
# # turtle.hideturtle()  # This is used to hide the turtle
# set_screen(window, turtle, start_x, start_y)
# draw_damien_hirst(window, turtle, start_x, start_y, colors)
#
# window.exitonclick()
#
# # End

# # Project, Instructor Code
# import turtle as turtle_module
# import random
# import colorgram
#
#
# def extract_colours_from_image(image_url):
#     colours = colorgram.extract(image_url, 100)
#     # We have chosen 100 as the number of colours here, because it is the
#     # maximum amount a painting or a picture can have distinct colours
#
#     colours_list = list()
#     for colour in colours:
#         colour = colour.rgb
#         colour = tuple(
#             colour)  # colour was already a tuple-like object, but for assurity, we have converted it to a tuple
#         colours_list.append(colour)
#
#     return colours_list
#
#
# turtle_module.colormode(255)
# tim = turtle_module.Turtle()
# tim.speed("fastest")
# tim.penup()
# tim.hideturtle()
# color_list = extract_colours_from_image("damien_hirst_spot_painting.webp")
# tim.setheading(225)
# tim.forward(300)
# tim.setheading(0)
# number_of_dots = 100
#
# for dot_count in range(1, number_of_dots + 1):
#     tim.dot(20, random.choice(color_list))
#     tim.forward(50)
#
#     if dot_count % 10 == 0:
#         tim.setheading(90)
#         tim.forward(50)
#         tim.setheading(180)
#         tim.forward(500)
#         tim.setheading(0)
#
# screen = turtle_module.Screen()  # This "Screen" class also comes from the turtle module, we need to create it in order to show the turtle graphics
# screen.exitonclick()  # You can guess from the name as to what this function does
#
# # End
